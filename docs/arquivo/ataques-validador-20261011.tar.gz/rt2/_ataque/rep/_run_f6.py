import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']; base = e['leitura']
for s in ['Com sorte pode chegar a dois milhões de dólares por mês.', 'Pode chegar a R$ duzentos por mês.',
          'Com sorte pode chegar a 10 milhões de dólares por mês.', 'Pode chegar a 10k por mês.',
          'Com sorte chega a US$ 100 por mês.', 'No base seriam US$ 75,830 por mês.', 'Seriam mil pessoas gravando cem horas por semana.']:
    e['leitura'] = base + ' ' + s
    print(run(r, x), '<-', s)
