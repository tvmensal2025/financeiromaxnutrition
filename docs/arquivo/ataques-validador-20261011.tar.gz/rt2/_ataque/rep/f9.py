r, x = load('CALC-BOA-01'); e = r['entrega']; k4 = e['contas'][3]; o = k4['o_que']
for s in ['Valor por mês depois do DARF e do IRPF', 'Valor por mês depois da carga tributária e dos encargos fiscais', 'Valor por mês antes do ISSQN e da NFS-e',
          'Valor por mês no Simples ou no lucro presumido', 'Valor por mês antes do DАS (A cirílico)', 'Valor por mês depois do Imposto (controle)']:
    k4['o_que'] = s; print(run(r, x), '<-', s)
