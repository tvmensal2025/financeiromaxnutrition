import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('REL-BOA-01'); R = r['entrega']['resumo']; f0 = R[0]['frase']      # "...de US$ 10 a US$ 50..., o cenário base, de US$ 25..." (refs E1)
print('controle:', run(r, x))
for t in ['A conta saiu em três cenários: de dez a cinquenta dólares por semana; o base é de duzentos dólares, com cem pessoas.',
          f0.replace('US$ 10 a US$ 50', 'US$ 10,000 a US$ 50,000').replace('US$ 25', 'US$ 25,000'),
          f0.replace('US$ 10 a US$ 50', 'US$ 10 mil a US$ 50 milhões').replace('US$ 25', 'US$ 25k'),
          f0.replace('US$', 'R$'),
          'O cenário base da conta é de US$ 15 por semana, com 10 pessoas.',                # 15 = minutos do treinamento (E2)
          'O cenário base usa 50 horas por semana por pessoa, que você precisa confirmar.']:  # 50 = US$ 50 do otimista
    R[0]['frase'] = t; R[0]['refs'] = 'E1, E2' if '15' in t else 'E1'
    print(run(r, x), '<-', t[:95])
R[1].update(frase='O convite foi aprovado com 3 perguntas e 18 linhas, e vale até 2026.', refs='E3, PEDIDO')   # dígitos do prazo do pedido
print(run(r, x), '<- 3, 18 e 2026 inventados, liberados pela ref PEDIDO')
