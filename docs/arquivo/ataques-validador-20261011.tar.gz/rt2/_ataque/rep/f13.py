r, x = load('CALC-BOA-01'); e = r['entrega']
e['contas'][0]['natureza'] = 'REALIZADO'          # K1 = horas que o fundador PLANEJA gravar (V1 x V2 são intenção, sem premissa)
e['premissas_a_confirmar'][0]['por_que_este_valor'] = 'x'; e['premissas_a_confirmar'][0]['como_confirmar'] = '-'
print(run(r, x))
