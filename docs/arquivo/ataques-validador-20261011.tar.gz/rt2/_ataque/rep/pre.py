import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
