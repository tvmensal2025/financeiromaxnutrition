import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']; base = e['leitura']
for s in ['Receberá com\ncerteza o valor.', 'O valor já está no\ncaixa.', 'A plataforma garante o pagamento e a garantia é do contrato.',
          'Sem a menor dúvida, certeza absoluta: pode contar com esse dinheiro.', 'Esse valor é guaranteed income, no risk.']:
    e['leitura'] = base + ' ' + s; print('CHK-10', run(r, x), repr(s))
e['leitura'] = base
for s in ['Não é dinheiro\nfácil: depende das horas.', 'Não é renda\nextra garantida.']:
    e['riscos'].append(s); print('CHK-11', run(r, x), repr(s)); e['riscos'].pop()
e['contas'][3]['o_que'] = 'Valor por mês, sem nota\nfiscal'; print('controle CHK-12 (mesma quebra, pego):', run(r, x))
