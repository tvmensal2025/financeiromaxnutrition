r, x = load('REL-BOA-01'); R = r['entrega']['resumo']
for ft in ['x', '.', 'ok']:
    for l in R: l['frase'] = ft; l['refs'] = 'E1, E2, E3, E4, PF-01'
    print(run(r, x), '<- resumo inteiro com a frase', repr(ft))
