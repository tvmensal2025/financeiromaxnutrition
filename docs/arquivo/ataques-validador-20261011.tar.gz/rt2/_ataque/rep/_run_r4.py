import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('REL-BOA-01'); R = r['entrega']['resumo']; f2 = R[2]['frase']       # refs "E4, PF-01"
for t in ['Veja o passo pf-01.', 'Veja o passo Pf-01.', 'Veja a etapa dec-024.', 'Estado dependencia_mudou.', 'Veja a etapa Е1 (E cirílico).', 'Veja a etapa E4 (controle).']:
    R[2]['frase'] = f2 + ' ' + t
    print(run(r, x), '<-', t)
