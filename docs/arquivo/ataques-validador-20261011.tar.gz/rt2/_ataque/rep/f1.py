r, x = load('CALC-BOA-01'); e = r['entrega']
E = {i['id']: i for i in e['entradas']}; K = {c['id']: c for c in e['contas']}
print('controle (boa):', run(r, x))
v = E['V5']['valor']; v.update(unidade='reais por dólar', origem='PREMISSA'); v.pop('ref'); v.pop('citacao')
E['V3']['valor']['unidade'] = 'dólares por hora aprovada'
K['K3']['resultado']['unidade'] = 'dólares por mês'; K['K4']['resultado']['unidade'] = 'reais por mês'
for l in e['cenarios']: l['resultado']['unidade'] = 'dólares por mês' if l['conta'] == 'K3' else 'reais por mês'
e['premissas_a_confirmar'].append({'entrada': 'V5', 'por_que_este_valor': 'Suposição minha.', 'como_confirmar': 'Ver no banco.'})
print('cambio PREMISSA "reais por dólar":', run(r, x))
e['contas'].append({'id': 'K5', 'o_que': 'Soma dos dois valores por mês', 'expressao': 'K3 + K4',
                    'resultado': {'valor': 485.33, 'unidade': 'reais por mês', 'origem': 'CALCULADO', 'ref': 'K5'}, 'natureza': 'PREVISTO'})
print('+ soma de dólares com reais (K3 + K4):', run(r, x))
