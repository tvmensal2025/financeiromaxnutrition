r, x = load('REL-BOA-01'); R = r['entrega']['resumo']
for t in ['O convite aprovado não pede para ninguém se cadastrar nem promete valores.', 'O convite aprovado pode ser publicado depois do cadastro, como o parecer pede.',
          'Nenhum agente contatou ou cadastrou ninguém em seu nome (controle).']:
    R[1].update(frase=t, refs='E3, E4'); print(run(r, x), '<-', t)
