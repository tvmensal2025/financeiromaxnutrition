r, x = load('CALC-BOA-01'); e = r['entrega']
e['contas'][3]['resultado']['unidade'] = 'reais por mês'
for l in e['cenarios']:
    if l['conta'] == 'K4': l['resultado']['unidade'] = 'reais por mês'
print('unidade "reais por mês":', run(r, x))
r, x = load('CALC-BOA-01'); e = r['entrega']
for l in e['cenarios']:
    if l['ajustes'] == 'V4 = 50': l['ajustes'] = 'V4 = 50%'
print('ajuste "V4 = 50%":', run(r, x))
for t in ['em 9 de outubro de 2026', 'em 2026-10-10']:
    r, x = load('CALC-BOA-01'); e = r['entrega']
    e['riscos'][1] = e['riscos'][1].replace('em 10/10/2026', t); print('data', t, ':', run(r, x))
r, x = load('CALC-BOA-01'); e = r['entrega']; e['leitura'] += ' Ou seja, cerca de 76 dólares no base.'; print('arredondar 75,83 para 76:', run(r, x))
r, x = load('CALC-BOA-01'); e = r['entrega']; e['riscos'][0] = 'Para cada 1 hora que a plataforma reprovar, o valor cai. O sinal é a parte aprovada.'; print('"1 hora":', run(r, x))
