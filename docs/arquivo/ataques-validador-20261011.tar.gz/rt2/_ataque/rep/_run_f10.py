import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']
def k5(expr, unid, o_que): e['contas'] = e['contas'][:4] + [{'id': 'K5', 'o_que': o_que, 'expressao': expr, 'resultado': {'valor': 226.67, 'unidade': unid, 'origem': 'CALCULADO', 'ref': 'K5'}, 'natureza': 'PREVISTO'}]
k5('K1 + V1', 'horas por mês', 'Horas mais pessoas'); print('horas + pessoas:', run(r, x))
k5('V3 + K3', 'US$ por mês', 'Valor por hora mais valor por mês'); e['contas'][4]['resultado']['valor'] = 76.33; print('US$ por hora + US$ por mês:', run(r, x))
r, x = load('CALC-BOA-01'); e = r['entrega']
e['entradas'].append({'id': 'V6', 'o_que': 'Fator de sorte, em vezes', 'valor': {'valor': 3, 'unidade': 'vezes', 'origem': 'PREMISSA'}})
e['premissas_a_confirmar'].append({'entrada': 'V6', 'por_que_este_valor': 'Suposição minha.', 'como_confirmar': 'Conferir no painel.'})
e['contas'][2]['expressao'] = 'K2 × V3 × V6 ÷ V6'; print('entrada decorativa (V6 ÷ V6):', run(r, x))
