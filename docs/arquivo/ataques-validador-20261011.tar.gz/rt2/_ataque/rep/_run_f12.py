import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']
e['entradas'].append({'id': 'V6', 'o_que': 'Fator de folga que não entra no valor, em percentual', 'valor': {'valor': 5, 'unidade': '%', 'origem': 'PREMISSA'}})
e['premissas_a_confirmar'].append({'entrada': 'V6', 'por_que_este_valor': 'Suposição minha.', 'como_confirmar': 'Conferir no painel.'})
e['contas'].append({'id': 'K5', 'o_que': 'Folga em horas por mês', 'expressao': 'K1 × V6 ÷ 100', 'resultado': {'valor': 10.83, 'unidade': 'horas por mês', 'origem': 'CALCULADO', 'ref': 'K5'}, 'natureza': 'PREVISTO'})
for l in e['cenarios']:
    if l['cenario'] == 'CONSERVADOR': l['ajustes'] = 'V6 = 8'; l['resultado']['valor'] = 75.83 if l['conta'] == 'K3' else 409.5   # igual ao BASE
e['leitura'] = 'Pela estimativa, o valor depende das horas aprovadas. É previsão.'; e['riscos'] = ['Se aprovarem poucas horas, o valor cai. O sinal é a parte aprovada.']; e['premissas_a_confirmar'][0]['por_que_este_valor'] = 'Suposição minha.'
print('CONSERVADOR == BASE:', run(r, x))
r, x = load('CALC-BOA-01'); e = r['entrega']
for p in e['resultado_principal']: p['sentido'] = 'MENOR_E_MELHOR'            # receita declarada "menor é melhor"
tr = {'V4 = 50': 'V4 = 90', 'V4 = 90': 'V4 = 50'}
vals = {'K3': {'CONSERVADOR': 97.5, 'OTIMISTA': 54.17}, 'K4': {'CONSERVADOR': 526.5, 'OTIMISTA': 292.5}}
for l in e['cenarios']:
    l['ajustes'] = tr.get(l['ajustes'], l['ajustes'])
    if l['cenario'] in vals[l['conta']]: l['resultado']['valor'] = vals[l['conta']][l['cenario']]
print('sentido invertido (CONSERVADOR com 90% de aprovação):', run(r, x))
