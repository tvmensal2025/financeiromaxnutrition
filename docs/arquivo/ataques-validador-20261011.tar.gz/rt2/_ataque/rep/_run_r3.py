import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('REL-BOA-01'); R = r['entrega']['resumo']; f3 = R[3]['frase']
for t in ['O plano está sem risco.', 'O plano tem zero furos.', 'Não há nenhum risco no plano.', 'O card está sem pendência.', 'Está tudo ok, tudo certinho.',
          'O plano é cem por cento seguro.', 'O plano é completamente seguro.', 'O cadastro está garantido e vai dar certo com certeza.', 'Não há nada para conferir.',
          'Ganho assegurado e rendas garantidas para todos.', 'Ainda não está tudo resolvido: falta o cadastro (honesto).', 'Tudo resolvido (controle).']:
    R[3]['frase'] = f3 + ' ' + t; print(run(r, x), '<-', t)
