import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']
t = e['entradas'][0]['valor']['citacao']['trecho_original']   # "...com 10 pessoas gravando 5 horas por semana..."
e['entradas'].append({'id': 'V6', 'o_que': 'Parte das horas gravadas que a plataforma cancela depois da aprovação',
  'valor': {'valor': 10, 'unidade': '%', 'origem': 'DADO_DO_FUNDADOR', 'ref': 'FON-PEDIDO-CALCULO-01',
            'citacao': {'trecho_original': t, 'fonte_importada_id': 'FON-PEDIDO-CALCULO-01'}}})
e['contas'].append({'id': 'K5', 'o_que': 'Horas gravadas por mês que a plataforma cancela depois', 'expressao': 'K1 × V6 ÷ 100',
  'resultado': {'valor': 21.67, 'unidade': 'horas por mês', 'origem': 'CALCULADO', 'ref': 'K5'}, 'natureza': 'REALIZADO'})
print(run(r, x))   # [] : 10% nunca foi dito pelo fundador (o 10 vem de "10 pessoas"), sem linha em premissas_a_confirmar
