r, x = load('REL-BOA-01'); R = r['entrega']['resumo']; f2 = R[2]['frase']       # refs "E4, PF-01"
for t in ['Veja o passo pf-01.', 'Veja o passo Pf-01.', 'Veja a etapa dec-024.', 'Estado dependencia_mudou.', 'Veja a etapa Е1 (E cirílico).', 'Veja a etapa E4 (controle).']:
    R[2]['frase'] = f2 + ' ' + t
    print(run(r, x), '<-', t)
