import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']
def conta(res, expr): return {'id': 'K5', 'o_que': 'Valor por hora', 'expressao': expr, 'resultado': {'valor': res, 'unidade': 'US$ por hora', 'origem': 'CALCULADO', 'ref': 'K5'}, 'natureza': 'PREVISTO'}
for res, expr, exato in [(1, 'V3 × 100 ÷ 100', 0.5), (0, 'V3 × V4 ÷ 100', 0.35)]:
    e['contas'] = e['contas'][:4] + [conta(res, expr)]
    print(f'exato {exato} declarado {res}:', run(r, x))
