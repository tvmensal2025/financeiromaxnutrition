import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']
e['entradas'] += [{'id': 'V6', 'o_que': 'Parte das horas que vira receita, em percentual', 'valor': {'valor': 20, 'unidade': '%', 'origem': 'PREMISSA'}},
                  {'id': 'V7', 'o_que': 'Custo de montar o grupo, em dólar', 'valor': {'valor': 300, 'unidade': 'US$', 'origem': 'PREMISSA'}}]
e['premissas_a_confirmar'] += [{'entrada': i, 'por_que_este_valor': 'Suposição minha.', 'como_confirmar': 'Conferir no painel.'} for i in ('V6', 'V7')]
k3 = 10*5*52/12*0.7*0.5; base = round(300/(k3*0.2), 2); otim = round(300/(k3*0.4), 2)
e['contas'].append({'id': 'K5', 'o_que': 'Meses para recuperar o custo, em meses', 'expressao': 'V7 ÷ (K3 × V6 ÷ 100)',
                    'resultado': {'valor': base, 'unidade': 'meses', 'origem': 'CALCULADO', 'ref': 'K5'}, 'natureza': 'PREVISTO'})
e['resultado_principal'] = [{'conta': 'K5', 'sentido': 'MENOR_E_MELHOR'}]
def lin(c, aj, v): return {'cenario': c, 'conta': 'K5', 'ajustes': aj, 'resultado': {'valor': v, 'unidade': 'meses', 'origem': 'CALCULADO', 'ref': 'K5/' + c}}
e['cenarios'] = [lin('CONSERVADOR', 'V6 = 0', 9999), lin('BASE', '—', base), lin('OTIMISTA', 'V6 = 40', otim)]
e['premissas_a_confirmar'][0]['por_que_este_valor'] = 'Suposição minha.'
e['leitura'] = 'Pela estimativa, o custo se paga em alguns meses. É previsão.'; e['riscos'] = ['Se aprovarem poucas horas, o prazo cresce. O sinal é a parte aprovada.']
print('CONSERVADOR com divisão por zero e resultado 9999:', run(r, x))
e['cenarios'][2] = lin('OTIMISTA', 'V6 = 40', otim + 5)
print('controle (OTIMISTA errado, sem divisão por zero):', run(r, x))
