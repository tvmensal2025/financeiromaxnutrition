import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); v = {i['id']: i for i in r['entrega']['entradas']}['V5']['valor']
t = 'Em 1 de março de 2019 o dólar fechou a R$ 5,40 por dólar segundo o banco, valor de referência do dossiê aprovado.'
x['fontes_importadas'].append({'fonte_importada_id': 'FON-DOSSIE-01', 'texto': t})
v.update(origem='FONTE_CITADA', data_da_fonte='2019-03-01', ref='FON-DOSSIE-01', citacao={'trecho_original': t, 'fonte_importada_id': 'FON-DOSSIE-01'})
print(run(r, x))   # cotação de 7 anos antes do card
