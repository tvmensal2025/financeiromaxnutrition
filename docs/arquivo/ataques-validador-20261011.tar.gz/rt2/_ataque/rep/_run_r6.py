import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('REL-BOA-01'); R = r['entrega']['resumo']
for t in ['O convite aprovado não pede para ninguém se cadastrar nem promete valores.', 'O convite aprovado pode ser publicado depois do cadastro, como o parecer pede.',
          'Nenhum agente contatou ou cadastrou ninguém em seu nome (controle).']:
    R[1].update(frase=t, refs='E3, E4'); print(run(r, x), '<-', t)
