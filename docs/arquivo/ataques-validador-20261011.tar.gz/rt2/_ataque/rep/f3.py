r, x = load('CALC-BOA-01'); e = r['entrega']; E = {i['id']: i for i in e['entradas']}
for f in x['fontes_importadas']:
    if f['fonte_importada_id'] == 'FON-PEDIDO-CALCULO-01':
        f['texto'] = f['texto'].replace('gravando 5 horas', 'gravando 5,5 horas')   # o fundador disse 5,5 horas
cortado = 'Quanto entra por mês para a Humano Digital com 10 pessoas gravando 5'
for i in ('V1', 'V2'): E[i]['valor']['citacao']['trecho_original'] = cortado   # termina antes de ",5"
print('V2=5 apoiado em "...gravando 5" (fonte diz 5,5):', run(r, x))
r, x = load('CALC-BOA-01'); e = r['entrega']; E = {i['id']: i for i in e['entradas']}
for f in x['fontes_importadas']:
    if f['fonte_importada_id'] == 'FON-PEDIDO-CALCULO-01':
        f['texto'] = f['texto'].replace('US$ 0,50 por hora', 'US$ 1.250 por hora')
E['V3']['valor']['valor'] = 250
E['V3']['valor']['citacao']['trecho_original'] = '250 por hora aprovada de cada pessoa indicada. Nem toda hora gravada é aprovada, e eu ainda não sei quanto é aprovado.'
e['leitura'] = 'Pela estimativa, o valor depende das horas aprovadas. É previsão.'; e['riscos'] = ['Se aprovarem poucas horas, o valor cai. O sinal é a parte aprovada.']
print('V3=250 apoiado em "250 por hora" (fonte diz 1.250), só CHK-CALCULO-02/COMUM-06:', [m for m in run(r, x) if m[0] in ('CHK-CALCULO-02', 'CHK-COMUM-06')])
