import subprocess, sys
r, x = load('CALC-BOA-01'); e = r['entrega']
e['entradas'][0]['valor']['valor'] = '@@X@@'
txt = json.dumps(r, ensure_ascii=False).replace('"@@X@@"', '1e999999999')   # um número JSON com expoente enorme (V1 = 1e999999999)
json.dump({'txt': txt, 'ctx': x}, open('/tmp/_f11.json', 'w'))
cod = "import json;from validador import validar;d=json.load(open('/tmp/_f11.json'));print(len(validar(d['txt'],d['ctx']).recusas),'recusas')"
try: print(subprocess.run([sys.executable, '-c', cod], capture_output=True, text=True, timeout=15).stdout)
except subprocess.TimeoutExpired: print('TRAVOU: validar() não voltou em 15 s (Fraction(Decimal("1E+999999999")) em spec_calculo_base.refazer)')
