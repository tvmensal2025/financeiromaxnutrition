import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']
e['contas'][0]['natureza'] = 'REALIZADO'          # K1 = horas que o fundador PLANEJA gravar (V1 x V2 são intenção, sem premissa)
e['premissas_a_confirmar'][0]['por_que_este_valor'] = 'x'; e['premissas_a_confirmar'][0]['como_confirmar'] = '-'
print(run(r, x))
