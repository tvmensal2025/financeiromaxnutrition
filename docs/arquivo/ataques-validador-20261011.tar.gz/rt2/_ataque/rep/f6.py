r, x = load('CALC-BOA-01'); e = r['entrega']; base = e['leitura']
for s in ['Com sorte pode chegar a dois milhões de dólares por mês.', 'Pode chegar a R$ duzentos por mês.',
          'Com sorte pode chegar a 10 milhões de dólares por mês.', 'Pode chegar a 10k por mês.',
          'Com sorte chega a US$ 100 por mês.', 'No base seriam US$ 75,830 por mês.', 'Seriam mil pessoas gravando cem horas por semana.']:
    e['leitura'] = base + ' ' + s
    print(run(r, x), '<-', s)
