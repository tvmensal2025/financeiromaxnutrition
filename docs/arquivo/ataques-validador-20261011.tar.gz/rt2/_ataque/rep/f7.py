r, x = load('CALC-BOA-01'); e = r['entrega']
E = {i['id']: i for i in e['entradas']}; K = {c['id']: c for c in e['contas']}
print('controle:', run(r, x))
K['K3']['resultado']['unidade'] = 'US$ por mês garantido'                     # CHK-CALCULO-10 (lista de certeza)
print('garantido na unidade:', run(r, x)); K['K3']['resultado']['unidade'] = 'US$ por mês'
E['V1']['valor']['unidade'] = 'pessoas com renda garantida'                   # termo proibido pelo pacote (CHK-CALCULO-11)
print('renda garantida na unidade:', run(r, x)); E['V1']['valor']['unidade'] = 'pessoas'
K['K1']['resultado']['unidade'] = 'horas por mês (média de 3.000 horas no setor)'  # número solto (CHK-CALCULO-09)
print('3.000 na unidade:', run(r, x)); K['K1']['resultado']['unidade'] = 'horas por mês'
K['K4']['resultado']['unidade'] = 'R$ por mês depois do imposto'                # conta fiscal (CHK-CALCULO-12)
print('imposto na unidade:', run(r, x)); K['K4']['resultado']['unidade'] = 'R$ por mês'
E['V4']['valor']['comentario'] = 'A Mimix aprova 93% em média, aprovação garantida, renda garantida, segundo o setor.'
print('campo extra dentro do objeto numero:', run(r, x))
