import json, copy
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
sp = prova.spec_padrao(); C = {c.id: c for c in listar_casos(sp)}
def load(i):
    s, x = montar_entrada(sp, C[i]); return json.loads(s), x
def run(r, x):
    rel = validar(json.dumps(r, ensure_ascii=False), x); return sorted({(f.id, f.motivo) for f in rel.recusas})
r, x = load('CALC-BOA-01'); e = r['entrega']; k4 = e['contas'][3]; o = k4['o_que']
for s in ['Valor por mês depois do DARF e do IRPF', 'Valor por mês depois da carga tributária e dos encargos fiscais', 'Valor por mês antes do ISSQN e da NFS-e',
          'Valor por mês no Simples ou no lucro presumido', 'Valor por mês antes do DАS (A cirílico)', 'Valor por mês depois do Imposto (controle)']:
    k4['o_que'] = s; print(run(r, x), '<-', s)
