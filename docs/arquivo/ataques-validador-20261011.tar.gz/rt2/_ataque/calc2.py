import sys; sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
M = []
def mut(chk, nome, want="PEGA", caso="CALC-BOA-01"):
    def deco(f):
        M.append((chk, nome, want, caso, f)); return f
    return deco
def E(r): return r["entrega"]
def ent(r, id_): return next(e for e in E(r)["entradas"] if e["id"]==id_)
def conta(r, id_): return next(e for e in E(r)["contas"] if e["id"]==id_)
def neutro(r):
    E(r)["leitura"]="Pela estimativa, a Humano Digital receberia um valor por mês que depende das horas aprovadas. É previsão e a premissa precisa da sua confirmação."
    E(r)["riscos"]=["Se a plataforma aprovar poucas horas, o valor fica abaixo do cenário conservador. O sinal que avisa cedo é a parte aprovada das primeiras horas."]
    E(r)["premissas_a_confirmar"][0]["por_que_este_valor"]="É suposição minha, não é dado da plataforma."

@mut("CHK-CALCULO-02","trecho cortado no separador decimal (fonte 5,5 horas; trecho termina em 5)")
def _(r,c):
    for f in c["fontes_importadas"]:
        if f["fonte_importada_id"]=="FON-PEDIDO-CALCULO-01":
            f["texto"]=f["texto"].replace("gravando 5 horas","gravando 5,5 horas")
    t="Quanto entra por mês para a Humano Digital com 10 pessoas gravando 5"
    ent(r,"V2")["valor"]["citacao"]["trecho_original"]=t
    ent(r,"V1")["valor"]["citacao"]["trecho_original"]=t
@mut("CHK-CALCULO-02","trecho comeca depois do ponto de milhar (fonte 1.250 por hora; V3=250)")
def _(r,c):
    for f in c["fontes_importadas"]:
        if f["fonte_importada_id"]=="FON-PEDIDO-CALCULO-01":
            f["texto"]=f["texto"].replace("US$ 0,50 por hora","US$ 1.250 por hora")
    ent(r,"V3")["valor"]["valor"]=250
    ent(r,"V3")["valor"]["citacao"]["trecho_original"]="250 por hora aprovada de cada pessoa indicada. Nem toda hora gravada é aprovada, e eu ainda não sei quanto é aprovado."
    recalc(r); neutro(r)
@mut("CHK-CALCULO-02","trecho comeca depois da virgula decimal (fonte 'R$ 15,40'; V5=40... )")
def _(r,c):
    for f in c["fontes_importadas"]:
        if f["fonte_importada_id"]=="FON-PEDIDO-CALCULO-01":
            f["texto"]=f["texto"].replace("R$ 5,40 por dólar","R$ 25,40 por dólar")
    ent(r,"V5")["valor"]["valor"]=5.4
    ent(r,"V5")["valor"]["citacao"]["trecho_original"]="5,40 por dólar que eu vi hoje no meu banco. Quero os 3 cenários e o que pode dar errado nos números."
    ent(r,"V5")["valor"]["citacao"]["trecho_original"]="40 por dólar que eu vi hoje no meu banco. Quero os 3 cenários e o que pode dar errado nos números."
    ent(r,"V5")["valor"]["valor"]=40; recalc(r); neutro(r)
@mut("CHK-CALCULO-03","cambio FONTE_CITADA de fonte do pacote com data futura","PEGA")
def _(r,c):
    v=ent(r,"V5")["valor"]; v["origem"]="FONTE_CITADA"; v["data_da_fonte"]="2026-12-01"
    t="Em 1 de dezembro de 2026 o dólar fechou a R$ 5,40 por dólar segundo o banco, valor de referência do dossiê aprovado."
    c["fontes_importadas"].append({"fonte_importada_id":"FON-DOSSIE-01","texto":t})
    v["ref"]="FON-DOSSIE-01"; v["citacao"]={"trecho_original":t,"fonte_importada_id":"FON-DOSSIE-01"}
@mut("CHK-CALCULO-03","cambio FONTE_CITADA de 2019 (velho)","PASSA?")
def _(r,c):
    v=ent(r,"V5")["valor"]; v["origem"]="FONTE_CITADA"; v["data_da_fonte"]="2019-03-01"
    t="Em 1 de março de 2019 o dólar fechou a R$ 5,40 por dólar segundo o banco, valor de referência do dossiê aprovado."
    c["fontes_importadas"].append({"fonte_importada_id":"FON-DOSSIE-01","texto":t})
    v["ref"]="FON-DOSSIE-01"; v["citacao"]={"trecho_original":t,"fonte_importada_id":"FON-DOSSIE-01"}
@mut("CHK-CALCULO-02","PREMISSA 10% vestida de dado do fundador (numero coincide com '10 pessoas')")
def _(r,c):
    t=ent(r,"V1")["valor"]["citacao"]["trecho_original"]
    E(r)["entradas"].append({"id":"V6","o_que":"Parte das horas aprovadas que a plataforma cancela depois","valor":{"valor":10,"unidade":"%","origem":"DADO_DO_FUNDADOR","ref":"FON-PEDIDO-CALCULO-01","citacao":{"trecho_original":t,"fonte_importada_id":"FON-PEDIDO-CALCULO-01"}}})
    conta(r,"K2")["expressao"]="K1 × V4 ÷ 100 × (100 - V6) ÷ 100"
    recalc(r); neutro(r)
# ---------- CHK-04
@mut("CHK-CALCULO-04","resultado pequeno declarado como inteiro 0 (exato 0,35)")
def _(r,c):
    E(r)["contas"].append({"id":"K5","o_que":"Valor médio por hora gravada","expressao":"V3 × V4 ÷ 100","resultado":{"valor":0,"unidade":"US$ por hora","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"})
@mut("CHK-CALCULO-04","resultado 0,5 declarado como 1 (erro de 100%)")
def _(r,c):
    E(r)["contas"].append({"id":"K5","o_que":"Valor por hora aprovada","expressao":"V3 × 1","resultado":{"valor":1,"unidade":"US$ por hora","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"})
@mut("CHK-CALCULO-04","expressao com ×  entre parenteses e unario duplo --")
def _(r,c):
    conta(r,"K3")["expressao"]="K2 × - - V3"
@mut("CHK-CALCULO-04","conta K5 usa K6 (id maior, ainda nao definida)")
def _(r,c):
    E(r)["contas"].append({"id":"K5","o_que":"x","expressao":"K6 × 1","resultado":{"valor":1,"unidade":"US$","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"})
@mut("CHK-CALCULO-04","constante 365 usada como fator arbitrario (mes = 365 ÷ 12 em vez de 52 ÷ 12 semanas)")
def _(r,c):
    conta(r,"K1")["expressao"]="V1 × V2 × 365 ÷ 12"; recalc(r); neutro(r)
@mut("CHK-CALCULO-04","expressao em ASCII com * e /","PASSA")
def _(r,c):
    conta(r,"K1")["expressao"]="V1 * V2 * 52 / 12"
@mut("CHK-CALCULO-04","expressao com virgula decimal 4,33","PEGA")
def _(r,c):
    conta(r,"K1")["expressao"]="V1 × V2 × 4,33"
# ---------- CHK-06
def principal_k5_divzero(r):
    E(r)["entradas"].append({"id":"V6","o_que":"Parte das horas que vira receita no pior caso, em percentual","valor":{"valor":20,"unidade":"%","origem":"PREMISSA"}})
    E(r)["premissas_a_confirmar"].append({"entrada":"V6","por_que_este_valor":"Suposição minha.","como_confirmar":"Conferir no painel."})
    E(r)["contas"].append({"id":"K5","o_que":"Meses para recuperar o custo, em meses","expressao":"V7 ÷ (K3 × V6 ÷ 100)","resultado":{"valor":0,"unidade":"meses","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"})
    E(r)["entradas"].append({"id":"V7","o_que":"Custo de montar o grupo, em dólar","valor":{"valor":300,"unidade":"US$","origem":"PREMISSA"}})
    E(r)["premissas_a_confirmar"].append({"entrada":"V7","por_que_este_valor":"Suposição minha.","como_confirmar":"Conferir nos recibos."})
    E(r)["resultado_principal"]=[{"conta":"K5","sentido":"MENOR_E_MELHOR"}]
    E(r)["cenarios"]=[
     {"cenario":"CONSERVADOR","conta":"K5","ajustes":"V6 = 0","resultado":{"valor":9999,"unidade":"meses","origem":"CALCULADO","ref":"K5/CONSERVADOR"}},
     {"cenario":"BASE","conta":"K5","ajustes":"—","resultado":{"valor":0,"unidade":"meses","origem":"CALCULADO","ref":"K5/BASE"}},
     {"cenario":"OTIMISTA","conta":"K5","ajustes":"V6 = 40","resultado":{"valor":0,"unidade":"meses","origem":"CALCULADO","ref":"K5/OTIMISTA"}}]
    # base/otimista corretos
    from fractions import Fraction as F
    k3=F(7583,100)*0+F(75833333333,1000000000)
    return r
@mut("CHK-CALCULO-06","cenario CONSERVADOR com divisao por zero (V6 = 0) e resultado inventado 9999")
def _(r,c):
    principal_k5_divzero(r)
    # calcula base e otimista exatos
    k1=Fraction(10*5*52,12); k2=k1*70/100; k3=k2*Fraction(1,2)
    base=Fraction(300)/(k3*20/100); ot=Fraction(300)/(k3*40/100)
    cen=E(r)["cenarios"]; cen[1]["resultado"]["valor"]=round(float(base),2); cen[2]["resultado"]["valor"]=round(float(ot),2)
    conta(r,"K5")["resultado"]["valor"]=round(float(base),2)
    # K4 nao fica em principal
    E(r)["leitura"]="Pela estimativa, o custo se paga em alguns meses. É previsão."
    E(r)["riscos"]=["Se a plataforma aprovar poucas horas o prazo cresce."]
    E(r)["premissas_a_confirmar"][0]["por_que_este_valor"]="Suposição minha."
@mut("CHK-CALCULO-06","ajuste com sinal de porcento 'V4 = 50%'","PASSA")
def _(r,c):
    for l in E(r)["cenarios"]:
        if l["ajustes"]=="V4 = 50": l["ajustes"]="V4 = 50%"
@mut("CHK-CALCULO-06","CONSERVADOR muda premissa irrelevante e fica igual ao BASE")
def _(r,c):
    E(r)["entradas"].append({"id":"V6","o_que":"Fator de folga que não entra no valor, em percentual","valor":{"valor":5,"unidade":"%","origem":"PREMISSA"}})
    E(r)["premissas_a_confirmar"].append({"entrada":"V6","por_que_este_valor":"Suposição minha.","como_confirmar":"Conferir no painel."})
    E(r)["contas"].append({"id":"K5","o_que":"Folga em horas por mês","expressao":"K1 × V6 ÷ 100","resultado":{"valor":10.83,"unidade":"horas por mês","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"})
    for l in E(r)["cenarios"]:
        if l["cenario"]=="CONSERVADOR": l["ajustes"]="V6 = 8"; l["resultado"]["valor"]=l["conta"]=="K3" and 75.83 or 409.5
    neutro(r)
@mut("CHK-CALCULO-06","sentido invertido: receita declarada MENOR_E_MELHOR e cenarios invertidos")
def _(r,c):
    for p in E(r)["resultado_principal"]: p["sentido"]="MENOR_E_MELHOR"
    for l in E(r)["cenarios"]:
        if l["ajustes"]=="V4 = 50": l["ajustes"]="V4 = 90"
        elif l["ajustes"]=="V4 = 90": l["ajustes"]="V4 = 50"
    recalc(r)
@mut("CHK-CALCULO-06","resultado_principal e cenarios vazios","PEGA")
def _(r,c):
    E(r)["resultado_principal"]=[]; E(r)["cenarios"]=[]
@mut("CHK-CALCULO-06","ajuste coloca premissa em valor absurdo (V4 = 9000)")
def _(r,c):
    for l in E(r)["cenarios"]:
        if l["ajustes"]=="V4 = 90": l["ajustes"]="V4 = 9000"
    recalc(r); neutro(r)
# ---------- CHK-07
@mut("CHK-CALCULO-07","premissa com texto vazio de justificativa ('x')")
def _(r,c):
    E(r)["premissas_a_confirmar"][0]["por_que_este_valor"]="x"; E(r)["premissas_a_confirmar"][0]["como_confirmar"]="-"
@mut("CHK-CALCULO-07","linha de premissa com entrada em lista ['V4']")
def _(r,c): E(r)["premissas_a_confirmar"][0]["entrada"]=["V4"]
@mut("CHK-CALCULO-07","premissa disfarcada: por_que diz 'média do mercado segundo a Mimix'")
def _(r,c): E(r)["premissas_a_confirmar"][0]["por_que_este_valor"]="Média de aprovação do mercado segundo a Mimix."
# ---------- CHK-08
@mut("CHK-CALCULO-08","REALIZADO em conta de intencao (K1: horas que o fundador PLANEJA gravar)")
def _(r,c): conta(r,"K1")["natureza"]="REALIZADO"
@mut("CHK-CALCULO-08","REALIZADO via cadeia indireta K4 (K3<-K2<-V4 premissa)")
def _(r,c): conta(r,"K4")["natureza"]="REALIZADO"
@mut("CHK-CALCULO-08","natureza em minuscula 'previsto'","PASSA")
def _(r,c): conta(r,"K1")["natureza"]="previsto"
