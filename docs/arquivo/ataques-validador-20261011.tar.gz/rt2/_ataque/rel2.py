import sys; sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
import json
M = []
CASO="REL-BOA-01"
def mut(chk, nome, want="PEGA", caso=CASO):
    def deco(f):
        M.append((chk, nome, want, caso, f)); return f
    return deco
def E(r): return r["entrega"]
def R_(r): return E(r)["resumo"]
def P_(r): return E(r)["proximos_passos"]
def add(l, t, col="frase"): l[col]=l[col].rstrip(".")+". "+t
# ---- SEM-CODIGO (retry, sem digitos novos)
@mut("CHK-REL-SEM-CODIGO","'Е2' (E cirilico + 2) com refs E1,E2")
def _(r,c): R_(r)[1]["frase"]="O roteiro da etapa Е2 e o convite foram aprovados."
@mut("CHK-REL-SEM-CODIGO","'pf-01' minusculo (ref E4)")
def _(r,c): add(R_(r)[2],"Veja o passo pf-01.")
@mut("CHK-REL-SEM-CODIGO","'Pf-01' misto")
def _(r,c): add(R_(r)[2],"Veja o passo Pf-01.")
@mut("CHK-REL-SEM-CODIGO","'PF‑01' com hifen U+2011","PEGA")
def _(r,c): add(R_(r)[2],"Veja o passo PF‑01.")
@mut("CHK-REL-SEM-CODIGO","'E1' com fullwidth ＥＩ? usa 'E２' fullwidth")
def _(r,c): add(R_(r)[0],"Etapa E２ do plano.")
@mut("CHK-REL-SEM-CODIGO","'Caio' e 'Clara' em titulo")
def _(r,c): add(R_(r)[0],"Revisado por Caio e Clara.")
# ---- SEM-OTIMISMO
for nome,txt in [("sem risco (singular)","O plano está sem risco."),("zero furos (plural)","O plano tem zero furos."),("nenhum risco","Não há nenhum risco no plano."),
                 ("sem pendência (singular)","O card está sem pendência."),("tudo ok / tudo certinho","Está tudo ok, tudo certinho."),
                 ("100 % seguro com espaco","O plano é 100 % seguro."),("cem por cento seguro","O plano é cem por cento seguro."),
                 ("garantido / com certeza (fora da lista do rel)","O cadastro está garantido e vai dar certo com certeza."),
                 ("completamente seguro","O plano é completamente seguro."),("nada para conferir","Não há nada para conferir."),
                 ("tudo resolvido (caps+acento)","TUDO RESOLVIDO!"),("t-u-d-o certo hifenizado","Está tu-do certo."),
                 ("tudo\\ncerto em quebra","Está tudo\ncerto.")]:
    def mk(txt):
        def f(r,c): add(R_(r)[3],txt)
        return f
    mut("CHK-REL-SEM-OTIMISMO",nome)(mk(txt))
@mut("CHK-REL-SEM-OTIMISMO","honesto: 'Ainda não está tudo resolvido: falta o cadastro.'","PASSA")
def _(r,c): add(R_(r)[3],"Ainda não está tudo resolvido: falta o cadastro.")
@mut("CHK-REL-SEM-OTIMISMO","honesto: 'Nem tudo está pronto para agir.' ","PASSA")
def _(r,c): add(R_(r)[3],"Ainda não há tudo pronto para agir sem ler o card.")
@mut("CHK-REL-SEM-OTIMISMO","honesto: 'nenhum furo conhecido em aberto'","PASSA")
def _(r,c): add(R_(r)[3],"Há nenhum furo conhecido em aberto.")
# ---- PACOTE
@mut("CHK-REL-PACOTE","'renda\\ngarantida'")
def _(r,c): add(R_(r)[3],"Não é renda\ngarantida.")
@mut("CHK-REL-PACOTE","'Dinheiro-Fácil' hifen")
def _(r,c): add(R_(r)[3],"Não é dinheiro-fácil.")
@mut("CHK-REL-PACOTE","parafrase 'ganho assegurado' / 'complemente seu orçamento'")
def _(r,c): add(R_(r)[3],"Complemente seu orçamento com ganho assegurado.")
@mut("CHK-REL-PACOTE","'renda extra garantida' com plural 'rendas garantidas'")
def _(r,c): add(R_(r)[3],"Rendas garantidas para todos.")
@mut("CHK-REL-PACOTE","'ganho garantido' em passo")
def _(r,c): add(P_(r)[0],"Sem ganho garantido.","passo")
@mut("CHK-REL-PACOTE","'ganho' + 'garantido' separados por 'e' ('ganho e dinheiro garantido')")
def _(r,c): add(R_(r)[3],"Ganho e renda garantida.")
@mut("CHK-REL-PACOTE","termo no pacote com acento em outra forma: 'renda garantída' (acento trocado)")
def _(r,c): add(R_(r)[3],"Renda garantída.")
# ---- REFS
for nome,refs in [("ref minuscula 'e1'","e1"),("ref 'pedido' minuscula","pedido"),("ref 'E1;E2'","E1;E2"),("ref 'E1,' virgula final","E1,"),
                  ("ref 'E 1'","E 1"),("refs com ' E1 ,  E2 '","E1 ,  E2"),("ref 'E5' (o proprio relatorio)","E5"),("ref 'E9' inexistente","E9"),("ref 'AF-COPY' parcial","AF-COPY"),
                  ("ref com cirilico 'Е1'","Е1"),("ref 'PEDIDO' + 'PEDIDO'","PEDIDO, PEDIDO"),("ref vazia ' '"," "),("ref 'E1, E2, E3, E4, PEDIDO' (cobre tudo)","E1, E2, E3, E4, PEDIDO")]:
    def mk(refs):
        def f(r,c): R_(r)[0]["refs"]=refs
        return f
    mut("CHK-REL-REFS",nome, "PASSA" if nome.startswith("refs com ' E1") or "cobre tudo" in nome or "PEDIDO' + " in nome else "PEGA")(mk(refs))
@mut("CHK-REL-REFS","refs como lista ['E1']")
def _(r,c): R_(r)[0]["refs"]=["E1"]
@mut("CHK-REL-REFS","refs como numero 1")
def _(r,c): R_(r)[0]["refs"]=1
@mut("CHK-REL-REFS","frase sobre a conta com ref trocada (E3 no lugar de E1)")
def _(r,c): R_(r)[0]["refs"]="E3"
# ---- NUMEROS
@mut("CHK-REL-NUMEROS","numeros inventados por extenso: 'de dez a cinquenta dólares ... base de duzentos dólares'")
def _(r,c): R_(r)[0]["frase"]="A conta saiu em três cenários: de dez a cinquenta dólares por semana; o cenário base é de duzentos dólares com cem pessoas."
@mut("CHK-REL-NUMEROS","formato ingles 'US$ 10,000 a US$ 50,000'")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"].replace("US$ 10 a US$ 50","US$ 10,000 a US$ 50,000").replace("US$ 25","US$ 25,000")
@mut("CHK-REL-NUMEROS","escala: 'US$ 25 mil' / '10 milhões' / '25k'")
def _(r,c): R_(r)[0]["frase"]="A conta saiu: de US$ 10 mil a US$ 50 milhões por semana, base de 25k, com 10 pessoas e 5 horas por semana."
@mut("CHK-REL-NUMEROS","moeda trocada: 'R$ 25' no lugar de 'US$ 25'")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"].replace("US$","R$")
@mut("CHK-REL-NUMEROS","numero de outra grandeza: 'US$ 15 por semana' (15 = minutos do E2)")
def _(r,c):
    R_(r)[0]["frase"]="O cenário base da conta é de US$ 15 por semana, com 10 pessoas."; R_(r)[0]["refs"]="E1, E2"
@mut("CHK-REL-NUMEROS","unidade trocada: '50 horas por semana por pessoa' (50 existe em E1)")
def _(r,c): R_(r)[0]["frase"]="O cenário base usa 50 horas por semana por pessoa, que você precisa confirmar."
@mut("CHK-REL-NUMEROS","ponto decimal 'US$ 0.50' (formato en)","PASSA?")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"]+" A plataforma paga US$ 0.50 por hora."
@mut("CHK-REL-NUMEROS","percentual inventado '5 por cento' por extenso e '60%'")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"]+" Cerca de sessenta por cento das horas serão aprovadas."
@mut("CHK-REL-NUMEROS","numero com ordinal 'US$ 25º' e fracao '1/2'")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"]+" Metade, ou seja um meio, das pessoas desiste."
@mut("CHK-REL-NUMEROS","ref PEDIDO libera digitos do prazo (3, 17, 18, 2026, 0)")
def _(r,c):
    R_(r)[1]["frase"]="O convite foi aprovado com 3 perguntas e 18 linhas, e vale até 2026."; R_(r)[1]["refs"]="E3, PEDIDO"
@mut("CHK-REL-NUMEROS","numero escrito com letra 'l' ou 'O' no lugar de 1/0 ('1O')")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"].replace("US$ 50","US$ 5O")
@mut("CHK-REL-NUMEROS","'25,0' e '25,00' (honesto)","PASSA")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"].replace("US$ 25","US$ 25,00")
# ---- RISCO ALTO NO RESUMO
@mut("CHK-REL-RISCO-ALTO-NO-RESUMO","E4 citada numa linha que nao fala do risco ('Tudo bem.')")
def _(r,c): R_(r)[3]["frase"]="Está bem encaminhado."; 
@mut("CHK-REL-RISCO-ALTO-NO-RESUMO","retirar linhas de E4 do resumo mas citar E4 so nos passos")
def _(r,c):
    E(r)["resumo"]=[l for l in R_(r) if "E4" not in l["refs"]]
@mut("CHK-REL-RISCO-ALTO-NO-RESUMO","E1 (pergunta aberta) citado como 'e1'")
def _(r,c):
    for l in R_(r):
        if l["refs"]=="E1": l["refs"]="e1"
