import sys; sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
M = []
def mut(chk, nome, want="PEGA", caso="CALC-BOA-01"):
    def deco(f):
        M.append((chk, nome, want, caso, f)); return f
    return deco
def E(r): return r["entrega"]
def ent(r, id_): return next(e for e in E(r)["entradas"] if e["id"]==id_)
def conta(r, id_): return next(e for e in E(r)["contas"] if e["id"]==id_)
def leit(r, extra):
    E(r)["leitura"]=E(r)["leitura"]+" "+extra
def risco(r, t): E(r)["riscos"].append(t)

# ---- CHK-09
@mut("CHK-CALCULO-09","'dois milhões de dólares' (de entre numero e moeda)")
def _(r,c): leit(r,"Com sorte pode chegar a dois milhões de dólares por mês.")
@mut("CHK-CALCULO-09","'R$ duzentos' (moeda antes do numero por extenso)")
def _(r,c): leit(r,"Pode chegar a R$ duzentos por mês.")
@mut("CHK-CALCULO-09","'10 milhões de dólares' (10 e valor de entrada)")
def _(r,c): leit(r,"Com sorte pode chegar a 10 milhões de dólares por mês.")
@mut("CHK-CALCULO-09","'100 dólares' (100 e constante do modelo)")
def _(r,c): leit(r,"Com sorte pode chegar a US$ 100 por mês, e a 365 pessoas.")
@mut("CHK-CALCULO-09","virgula inglesa 'US$ 75,830' lida como 75,83")
def _(r,c): leit(r,"No cenário base seriam US$ 75,830 por mês.")
@mut("CHK-CALCULO-09","numero na unidade (US$ 3.000 por mês) fora do texto livre")
def _(r,c): conta(r,"K3")["resultado"]["unidade"]="US$ por mês (média de US$ 3.000 por mês no mercado)"
@mut("CHK-CALCULO-09","numero dentro de campo extra do objeto numero (comentario)")
def _(r,c): ent(r,"V4")["valor"]["comentario"]="A Mimix aprova 93% em média, segundo o setor."
@mut("CHK-CALCULO-09","'cerca de 76 dólares' (arredondamento honesto de 75,83)","PASSA")
def _(r,c): leit(r,"Ou seja, cerca de 76 dólares no base.")
@mut("CHK-CALCULO-09","numero com 10k / 5 mi (sufixo)")
def _(r,c): leit(r,"Alguns grupos chegam a 10k por mês.")
@mut("CHK-CALCULO-09","porcentagem por extenso com 'por cento' separado por quebra","PEGA")
def _(r,c): leit(r,"Aprovação de noventa e cinco por cento é possível.")
@mut("CHK-CALCULO-09","numero com algarismo fullwidth ９９９")
def _(r,c): leit(r,"Pode chegar a US$ ９９９ por mês.")
@mut("CHK-CALCULO-09","numero escondido depois de prefixo de id (FON-9999 / K9999)")
def _(r,c): leit(r,"Veja K9999 e DEC-1000000 para mais detalhes.")
@mut("CHK-CALCULO-09","numero em data falsa 5000/12/20 ")
def _(r,c): leit(r,"Receberia US$ 5000/12/20 por mês.")
@mut("CHK-CALCULO-09","numeros por extenso sem moeda ('mil pessoas', 'cem horas')")
def _(r,c): leit(r,"Seriam mil pessoas gravando cem horas por semana.")
# ---- CHK-10
@mut("CHK-CALCULO-10","'garante' / 'garantia' (verbo e substantivo fora da lista)")
def _(r,c): leit(r,"A plataforma garante o pagamento todo mês e a garantia é do contrato.")
@mut("CHK-CALCULO-10","quebra de linha dentro de 'com\\ncerteza'")
def _(r,c): leit(r,"Receberá com\ncerteza o valor.")
@mut("CHK-CALCULO-10","'com certeza' com hifen/nbsp-hifen")
def _(r,c): leit(r,"Receberá com‑certeza o valor.")
@mut("CHK-CALCULO-10","parafrase 'sem a menor dúvida' / 'certeza absoluta' / 'pode contar com'")
def _(r,c): leit(r,"Sem a menor dúvida, certeza absoluta: pode contar com esse dinheiro.")
@mut("CHK-CALCULO-10","'garantido' dentro de unidade")
def _(r,c): conta(r,"K3")["resultado"]["unidade"]="US$ por mês garantido"
@mut("CHK-CALCULO-10","ingles misturado: 'guaranteed income, no risk'")
def _(r,c): leit(r,"Esse valor é guaranteed income, no risk.")
@mut("CHK-CALCULO-10","'g a r a n t i d o' com espacos / emoji 💰")
def _(r,c): leit(r,"💰 Valor g a r a n t i d o!")
@mut("CHK-CALCULO-10","'garantido' com zero-width no meio")
def _(r,c): leit(r,"Valor garan​tido.")
@mut("CHK-CALCULO-10","'garantído' com acento trocado e MAIUSCULA")
def _(r,c): leit(r,"Valor GARANTÍDO.")
@mut("CHK-CALCULO-10","'garantido' dentro de campo extra do numero (nota)")
def _(r,c): ent(r,"V4")["valor"]["nota"]="aprovação garantida"
@mut("CHK-CALCULO-10","'já está no caixa' com ZWJ e nbsp")
def _(r,c): leit(r,"O valor já está no‍ caixa.")
# ---- CHK-11
@mut("CHK-CALCULO-11","'renda\\ngarantida' quebrada em linhas")
def _(r,c): leit(r,"Isso é renda\ngarantida para a empresa.")
@mut("CHK-CALCULO-11","'Renda  Garantida' maiúsculas+dois espaços")
def _(r,c): leit(r,"Isso é Renda  Garantida para a empresa.")
@mut("CHK-CALCULO-11","parafrase 'complemente seu orçamento' / 'ganho assegurado'")
def _(r,c): leit(r,"Complemente seu orçamento com ganho assegurado.")
@mut("CHK-CALCULO-11","'dinheiro  facil' em riscos")
def _(r,c): risco(r,"Não é dinheiro  facil: o valor depende das horas aprovadas.")
@mut("CHK-CALCULO-11","'dinheiro fácil' com letra cirilica 'а' (facil -> fаcil)")
def _(r,c): risco(r,"Parece dinheiro fаcil mas depende das horas aprovadas.")
@mut("CHK-CALCULO-11","'renda garantida' em o_que de entrada")
def _(r,c): ent(r,"V1")["o_que"]="Pessoas gravando com renda garantida"
@mut("CHK-CALCULO-11","'renda garantida' no campo 'unidade'")
def _(r,c): ent(r,"V1")["valor"]["unidade"]="pessoas com renda garantida"
@mut("CHK-CALCULO-11","termo proibido em `ajustes` (texto) ")
def _(r,c):
    for l in E(r)["cenarios"]:
        if l["cenario"]=="BASE": l["ajustes"]="— renda garantida"
# ---- CHK-12
@mut("CHK-CALCULO-12","DARF / IRPF / NFS-e em o_que")
def _(r,c): conta(r,"K4")["o_que"]="Valor que a empresa recebe por mês, depois do DARF e do IRPF"
@mut("CHK-CALCULO-12","carga tributária / encargos fiscais")
def _(r,c): conta(r,"K4")["o_que"]="Valor por mês depois da carga tributária e dos encargos fiscais"
@mut("CHK-CALCULO-12","ISSQN e NFS-e")
def _(r,c): ent(r,"V3")["o_que"]="Valor por hora aprovada, antes do ISSQN e da NFS-e"
@mut("CHK-CALCULO-12","'DAS' com zero-width D\\u200bAS")
def _(r,c): conta(r,"K4")["o_que"]="Valor que a empresa recebe por mês, antes do D​AS"
@mut("CHK-CALCULO-12","'DAS' com A cirilico (DАS)")
def _(r,c): conta(r,"K4")["o_que"]="Valor que a empresa recebe por mês, antes do DАS"
@mut("CHK-CALCULO-12","'Simples' (sem Nacional) e 'lucro presumido'")
def _(r,c): conta(r,"K4")["o_que"]="Valor por mês no Simples, ou no lucro presumido"
@mut("CHK-CALCULO-12","imposto na unidade da conta")
def _(r,c): conta(r,"K4")["resultado"]["unidade"]="R$ por mês depois do imposto"
@mut("CHK-CALCULO-12","'imposto' com quebra de linha em 'nota\\nfiscal'")
def _(r,c): conta(r,"K4")["o_que"]="Valor por mês, sem nota\nfiscal"
@mut("CHK-CALCULO-12","imposto em o_que da entrada ('Imposto' maiusc.)","PEGA")
def _(r,c): ent(r,"V3")["o_que"]="Valor por hora, já descontado o Imposto"
