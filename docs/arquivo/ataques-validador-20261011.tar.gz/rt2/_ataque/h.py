import sys, json, copy
sys.path.insert(0, "/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/motor/validador")
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_entrada
from validador import validar
spec = prova.spec_padrao()
CASOS = {c.id: c for c in listar_casos(spec)}
def base(id_):
    c = CASOS[id_]
    resp, ctx = montar_entrada(spec, c)
    return json.loads(resp), ctx
def rodar(resp, ctx, show=True, raw=False):
    txt = resp if isinstance(resp, str) else json.dumps(resp, ensure_ascii=False)
    try:
        rel = validar(txt, ctx)
    except Exception as e:
        if show: print("  EXCECAO", type(e).__name__, str(e)[:200])
        return ("EXC", type(e).__name__)
    rs = sorted({(f.id, f.motivo) for f in rel.recusas})
    ms = sorted({(f.id, f.motivo) for f in rel.falhas if f.gravidade != "RECUSA"})
    if show:
        print("  RECUSAS:", rs, "| outras:", ms)
    return rs, ms, rel

from fractions import Fraction
from decimal import Decimal
import re as _re
def _ev(expr, nomes):
    e = expr.replace("×", "*").replace("÷", "/")
    e = _re.sub(r"([VK]\d+)", lambda m: f"N['{m.group(1)}']", e)
    e = _re.sub(r"(?<![\w'\[])(\d+)(?![\w'\]])", r"F(\1)", e)
    return eval(e, {"F": Fraction, "N": nomes})
def _r(f, casas=2):
    q = Fraction(10) ** casas
    n = round(f * q)
    return float(Fraction(n, 1) / q) if casas else int(n)
def recalc(r, casas=2):
    """recalcula resultados de contas e cenarios (so ajustes) a partir das entradas/expressoes (independente do validador)."""
    en = r["entrega"]
    vals = {e["id"]: Fraction(str(e["valor"]["valor"])) for e in en["entradas"]}
    def contas(v):
        N = dict(v); out = {}
        for c in en["contas"]:
            N[c["id"]] = _ev(c["expressao"], N); out[c["id"]] = N[c["id"]]
        return out
    base = contas(vals)
    for c in en["contas"]:
        c["resultado"]["valor"] = _r(base[c["id"]], casas)
    for l in en["cenarios"]:
        aj = {}
        if l["ajustes"].strip() not in ("—", "-", ""):
            for p in l["ajustes"].split(";"):
                k, v = p.split("="); aj[k.strip()] = Fraction(v.strip().replace(",", "."))
        v2 = {**vals, **aj}
        res = contas(v2) if aj else base
        l["resultado"]["valor"] = _r(res[l["conta"]], casas)
    return r
