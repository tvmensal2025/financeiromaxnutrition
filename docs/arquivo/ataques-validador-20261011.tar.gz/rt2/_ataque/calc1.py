import sys; sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
M = []
def mut(chk, nome, want="PEGA", caso="CALC-BOA-01"):
    def deco(f):
        M.append((chk, nome, want, caso, f)); return f
    return deco
def E(r): return r["entrega"]
def ent(r, id_): return next(e for e in E(r)["entradas"] if e["id"]==id_)
def conta(r, id_): return next(e for e in E(r)["contas"] if e["id"]==id_)

# ---------- CHK-CALCULO-01
@mut("CHK-CALCULO-01","id com quebra de linha V4\\n duplicado decorativo","PEGA")
def _(r,c):
    e=copy.deepcopy(ent(r,"V4")); e["id"]="V4\n"; e["valor"]["valor"]=60; E(r)["entradas"].append(e)
@mut("CHK-CALCULO-01","entrada usada so em conta decorativa (K3 x V6 / V6)","PASSA?")
def _(r,c):
    E(r)["entradas"].append({"id":"V6","o_que":"Fator de sorte, em vezes","valor":{"valor":3,"unidade":"vezes","origem":"PREMISSA"}})
    E(r)["premissas_a_confirmar"].append({"entrada":"V6","por_que_este_valor":"Suposição minha.","como_confirmar":"Conferir no painel."})
    conta(r,"K3")["expressao"]="K2 × V3 × V6 ÷ V6"
@mut("CHK-CALCULO-01","valor numerico como texto '10'","PEGA")
def _(r,c): ent(r,"V1")["valor"]["valor"]="10"
@mut("CHK-CALCULO-01","unidade so com espaco/zero-width","PEGA")
def _(r,c): ent(r,"V1")["valor"]["unidade"]="​"
@mut("CHK-CALCULO-01","origem 'CALCULADO' em entrada","PEGA")
def _(r,c): ent(r,"V3")["valor"]["origem"]="CALCULADO"
@mut("CHK-CALCULO-01","16 entradas (V16)","PEGA")
def _(r,c): E(r)["entradas"].append({"id":"V16","o_que":"x","valor":{"valor":1,"unidade":"u","origem":"PREMISSA"}})

# ---------- CHK-CALCULO-02
@mut("CHK-CALCULO-02","PREMISSA promovida a DADO_DO_FUNDADOR por numero coincidente (10% = '10 pessoas')","PEGA")
def _(r,c):
    # V6 = 10 (% de cancelamento) vestido de dado do fundador, apoiado em '10 pessoas'
    t=ent(r,"V1")["valor"]["citacao"]["trecho_original"]
    E(r)["entradas"].append({"id":"V6","o_que":"Parte das horas aprovadas que é cancelada depois","valor":{"valor":10,"unidade":"%","origem":"DADO_DO_FUNDADOR","ref":"FON-PEDIDO-CALCULO-01","citacao":{"trecho_original":t,"fonte_importada_id":"FON-PEDIDO-CALCULO-01"}}})
    conta(r,"K2")["expressao"]="K1 × V4 ÷ 100 × (100 - V6) ÷ 100"
    recalc(r)
@mut("CHK-CALCULO-02","trecho termina no meio de numero (fonte '5,5 horas', trecho corta em '5')","PEGA")
def _(r,c):
    for f in c["fontes_importadas"]:
        if f["fonte_importada_id"]=="FON-PEDIDO-CALCULO-01":
            f["texto"]=f["texto"].replace("gravando 5 horas","gravando 5,5 horas")
    t="Quanto entra por mês para a Humano Digital com 10 pessoas gravando 5"
    for i in ("V1","V2"):
        ent(r,i)["valor"]["citacao"]["trecho_original"]=t
@mut("CHK-CALCULO-02","trecho comeca no meio de numero ('1.250' -> '250')","PEGA")
def _(r,c):
    for f in c["fontes_importadas"]:
        if f["fonte_importada_id"]=="FON-PEDIDO-CALCULO-01":
            f["texto"]=f["texto"].replace("US$ 0,50 por hora","US$ 1.250 por hora")
    ent(r,"V3")["valor"]["valor"]=250
    ent(r,"V3")["valor"]["citacao"]["trecho_original"]="250 por hora aprovada de cada pessoa indicada. Nem toda hora gravada é aprovada, e eu ainda não sei quanto é aprovado."
    recalc(r)
@mut("CHK-CALCULO-02","valor 5400 apoiado em 'R$ 5,40' (virgula lida como milhar ingles)","PEGA")
def _(r,c):
    ent(r,"V5")["valor"]["valor"]=540; recalc(r)
@mut("CHK-CALCULO-02","FONTE_CITADA com data de 2019 (cotacao velha)","PASSA?")
def _(r,c):
    v=ent(r,"V5")["valor"]; v["origem"]="FONTE_CITADA"; v["data_da_fonte"]="2019-03-01"
    c["fontes_importadas"].append({"fonte_importada_id":"FON-DOSSIE-01","texto":"Em 1 de março de 2019 o dólar fechou a R$ 5,40 por dólar segundo o banco, valor de referência do dossiê aprovado."})
    v["ref"]="FON-DOSSIE-01"; v["citacao"]={"trecho_original":"Em 1 de março de 2019 o dólar fechou a R$ 5,40 por dólar segundo o banco, valor de referência do dossiê aprovado.","fonte_importada_id":"FON-DOSSIE-01"}
@mut("CHK-CALCULO-02","trecho com letra cirilica no meio (equivalencia visual)","PEGA")
def _(r,c):
    t=ent(r,"V3")["valor"]["citacao"]["trecho_original"].replace("plataforma","plаtaforma")
    ent(r,"V3")["valor"]["citacao"]["trecho_original"]=t
# ---------- CHK-CALCULO-03 / 05
def palavras(r):
    ent(r,"V5")["valor"]["unidade"]="reais por dólar"
    ent(r,"V5")["valor"]["origem"]="PREMISSA"
    for k in ("ref","citacao"): ent(r,"V5")["valor"].pop(k,None)
    ent(r,"V3")["valor"]["unidade"]="dólares por hora aprovada"
    conta(r,"K3")["resultado"]["unidade"]="dólares por mês"
    conta(r,"K4")["resultado"]["unidade"]="reais por mês"
    for l in E(r)["cenarios"]:
        l["resultado"]["unidade"]="dólares por mês" if l["conta"]=="K3" else "reais por mês"
    E(r)["premissas_a_confirmar"].append({"entrada":"V5","por_que_este_valor":"Suposição minha para a cotação.","como_confirmar":"Ver a cotação no banco."})
@mut("CHK-CALCULO-03","cambio PREMISSA com unidade por extenso 'reais por dólar'","PEGA")
def _(r,c): palavras(r)
@mut("CHK-CALCULO-03","cambio PREMISSA com unidade 'BRL por USD'","PEGA")
def _(r,c):
    palavras(r); ent(r,"V5")["valor"]["unidade"]="BRL por USD"
@mut("CHK-CALCULO-03","cambio PREMISSA 'R$ por dólar' (um simbolo so)","PEGA")
def _(r,c):
    palavras(r); ent(r,"V5")["valor"]["unidade"]="R$ por dólar"; conta(r,"K3")["resultado"]["unidade"]="US$ por mês"
    for l in E(r)["cenarios"]:
        if l["conta"]=="K3": l["resultado"]["unidade"]="US$ por mês"
    ent(r,"V3")["valor"]["unidade"]="US$ por hora aprovada"
@mut("CHK-CALCULO-03","cambio ENTREGA_APROVADA sem data","PEGA")
def _(r,c): ent(r,"V5")["valor"]["origem"]="ENTREGA_APROVADA"
@mut("CHK-CALCULO-03","cambio com unidade 'cotação do dólar em reais'","PEGA")
def _(r,c):
    palavras(r); ent(r,"V5")["valor"]["unidade"]="cotação do dólar em reais"
@mut("CHK-CALCULO-03","cambio FONTE_CITADA com data_da_fonte futura (depois do card)","PEGA")
def _(r,c):
    v=ent(r,"V5")["valor"]; v["origem"]="FONTE_CITADA"; v["data_da_fonte"]="2026-12-01"
@mut("CHK-CALCULO-05","soma dolar + real, tudo por extenso","PEGA")
def _(r,c):
    palavras(r)
    E(r)["contas"].append({"id":"K5","o_que":"Soma dos dois valores por mês","expressao":"K3 + K4","resultado":{"valor":485.33,"unidade":"reais por mês","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"})
    recalc(r)
@mut("CHK-CALCULO-05","soma dolar + real usando USD / BRL","PEGA")
def _(r,c):
    palavras(r); conta(r,"K3")["resultado"]["unidade"]="USD por mês"; conta(r,"K4")["resultado"]["unidade"]="BRL por mês"
    E(r)["contas"].append({"id":"K5","o_que":"Soma","expressao":"K3 + K4","resultado":{"valor":0,"unidade":"BRL por mês","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"}); recalc(r)
@mut("CHK-CALCULO-05","soma horas por mes + pessoas (grandezas sem moeda)","PEGA")
def _(r,c):
    E(r)["contas"].append({"id":"K5","o_que":"Horas mais pessoas","expressao":"K1 + V1","resultado":{"valor":0,"unidade":"horas por mês","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"}); recalc(r)
@mut("CHK-CALCULO-05","soma US$ por hora + US$ por mes (periodos diferentes)","PEGA")
def _(r,c):
    E(r)["contas"].append({"id":"K5","o_que":"Valor por hora mais valor por mês","expressao":"V3 + K3","resultado":{"valor":0,"unidade":"US$ por mês","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"}); recalc(r)
@mut("CHK-CALCULO-05","honesto: unidade da conta em reais por extenso ('reais por mês') com cambio R$ por US$","PASSA")
def _(r,c):
    conta(r,"K4")["resultado"]["unidade"]="reais por mês"
    for l in E(r)["cenarios"]:
        if l["conta"]=="K4": l["resultado"]["unidade"]="reais por mês"
@mut("CHK-CALCULO-05","cambio inverso: K4 = K3 ÷ V5","PEGA")
def _(r,c):
    conta(r,"K4")["expressao"]="K3 ÷ V5"; recalc(r)
