import sys, importlib, json
sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
def go(modname, only=None):
    mod = importlib.import_module(modname)
    for chk, nome, want, caso, f in mod.M:
        if only and only not in chk+nome: continue
        r, c = base(caso)
        r = copy.deepcopy(r)
        try:
            ret = f(r, c)
        except Exception as ex:
            print(f"[MUTACAO QUEBROU] {chk} | {nome}: {type(ex).__name__} {ex}"); continue
        payload = ret if isinstance(ret, str) else r
        if not isinstance(ret, str):
            payload = json.dumps(r, ensure_ascii=False)
            import re as _re2
            payload = _re2.sub(r'"@@RAW:([^@]*)@@"', r'\1', payload)
        out = rodar(payload, c, show=False)
        if out and out[0]=="EXC":
            print(f"[EXCECAO] {chk} | {nome}: {out[1]}"); continue
        rs, ms, rel = out
        ids = sorted({i for i,_ in rs})
        pego = chk in ids
        tag = "PEGO " if pego else ("PEGO_OUTRA" if rs else "PASSOU")
        print(f"[{tag}] {chk} | {nome} (espera {want})\n      recusas={rs}\n      marcas={ms}")
if __name__=="__main__":
    go(sys.argv[1], sys.argv[2] if len(sys.argv)>2 else None)
