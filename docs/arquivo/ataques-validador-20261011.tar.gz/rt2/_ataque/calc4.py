import sys; sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
M = []
def mut(chk, nome, want="PEGA", caso="CALC-BOA-01"):
    def deco(f):
        M.append((chk, nome, want, caso, f)); return f
    return deco
def E(r): return r["entrega"]
def ent(r, id_): return next(e for e in E(r)["entradas"] if e["id"]==id_)
def conta(r, id_): return next(e for e in E(r)["contas"] if e["id"]==id_)
def neutro(r):
    E(r)["leitura"]="Pela estimativa, a Humano Digital receberia um valor por mês que depende das horas aprovadas. É previsão e a premissa precisa da sua confirmação."
    E(r)["riscos"]=["Se a plataforma aprovar poucas horas, o valor fica abaixo do cenário conservador. O sinal que avisa cedo é a parte aprovada das primeiras horas."]

@mut("CHK-CALCULO-04","0,5 declarado como 1 (V3 x 100 ÷ 100)")
def _(r,c):
    E(r)["contas"].append({"id":"K5","o_que":"Valor por hora aprovada","expressao":"V3 × 100 ÷ 100","resultado":{"valor":1,"unidade":"US$ por hora aprovada","origem":"CALCULADO","ref":"K5"},"natureza":"REALIZADO"})
@mut("CHK-CALCULO-04","0,35 declarado como 0")
def _(r,c):
    E(r)["contas"].append({"id":"K5","o_que":"Valor médio por hora gravada","expressao":"V3 × V4 ÷ 100","resultado":{"valor":0,"unidade":"US$ por hora gravada","origem":"CALCULADO","ref":"K5"},"natureza":"PREVISTO"})
@mut("CHK-CALCULO-04","resultado 216,67 declarado como 217 (honesto)","PASSA")
def _(r,c): conta(r,"K1")["resultado"]["valor"]=217
@mut("CHK-CALCULO-11","dinheiro\\nfácil quebrado em linhas")
def _(r,c): E(r)["riscos"].append("Não é dinheiro\nfácil: depende das horas aprovadas.")
@mut("CHK-CALCULO-09","numero com milhar em unidade (sem moeda): 3.000 horas")
def _(r,c): conta(r,"K1")["resultado"]["unidade"]="horas por mês (média de 3.000 horas no setor)"
@mut("CHK-CALCULO-12","'imposto' na unidade sem moeda")
def _(r,c): conta(r,"K1")["resultado"]["unidade"]="horas por mês depois do imposto"
# ---- estrutura
@mut("COMUM-01","sem leitura")
def _(r,c): del E(r)["leitura"]
@mut("COMUM-01","leitura como lista")
def _(r,c): E(r)["leitura"]=[E(r)["leitura"]]
@mut("COMUM-01","riscos como texto")
def _(r,c): E(r)["riscos"]=E(r)["riscos"][0]
@mut("COMUM-01","riscos lista vazia")
def _(r,c): E(r)["riscos"]=[]
@mut("COMUM-01","riscos 6 itens")
def _(r,c): E(r)["riscos"]=E(r)["riscos"]*2
@mut("COMUM-01","limites 5 itens")
def _(r,c): E(r)["limites"]=E(r)["limites"]*3
@mut("COMUM-01","leitura 700 chars exatos","PASSA")
def _(r,c):
    base="Pela estimativa, valor depende das horas aprovadas. É previsão. "; E(r)["leitura"]=(base*20)[:700]
@mut("COMUM-01","leitura 701 chars")
def _(r,c):
    base="Pela estimativa, valor depende das horas aprovadas. É previsão. "; E(r)["leitura"]=(base*20)[:701]
@mut("COMUM-01","pergunta 301 chars")
def _(r,c): E(r)["pergunta"]=("Quanto a Humano Digital recebe por mês? "*20)[:301]
@mut("COMUM-01","um risco gigante (7000 chars) estoura limite 6000")
def _(r,c): E(r)["riscos"]=["Risco de queda das horas aprovadas, com sinal no painel. "*130]
@mut("COMUM-01","campo extra entrega.numeros")
def _(r,c): E(r)["numeros"]=["US$ 1.000"]
@mut("COMUM-01","campo extra na linha da entrada (nota)")
def _(r,c): E(r)["entradas"][0]["nota"]="renda garantida com certeza"
@mut("COMUM-01","valor da entrada e numero cru (10) em vez de objeto")
def _(r,c): E(r)["entradas"][0]["valor"]=10
@mut("COMUM-01","entradas como dicionario")
def _(r,c): E(r)["entradas"]={e["id"]:e for e in E(r)["entradas"]}
@mut("COMUM-01","cenarios como texto")
def _(r,c): E(r)["cenarios"]="três cenários"
@mut("COMUM-01","16 contas")
def _(r,c):
    for i in range(5,17):
        E(r)["contas"].append({"id":f"K{i}","o_que":"x","expressao":"K1","resultado":{"valor":216.67,"unidade":"horas por mês","origem":"CALCULADO","ref":f"K{i}"},"natureza":"PREVISTO"})
@mut("COMUM-01","resultado da conta como texto '75,83 US$'")
def _(r,c): conta(r,"K3")["resultado"]="75,83 US$"
@mut("COMUM-01","natureza como lista")
def _(r,c): conta(r,"K3")["natureza"]=["PREVISTO"]
@mut("COMUM-01","expressao como lista")
def _(r,c): conta(r,"K3")["expressao"]=["K2","×","V3"]
@mut("COMUM-01","id da entrada como numero 4")
def _(r,c): E(r)["entradas"][3]["id"]=4
@mut("COMUM-01","citacao como texto simples")
def _(r,c): ent(r,"V1")["valor"]["citacao"]="Quanto entra por mês"
@mut("COMUM-01","citacao.fonte_importada_id como lista")
def _(r,c): ent(r,"V1")["valor"]["citacao"]["fonte_importada_id"]=["FON-PEDIDO-CALCULO-01"]
@mut("COMUM-01","ref como lista")
def _(r,c): ent(r,"V1")["valor"]["ref"]=["FON-PEDIDO-CALCULO-01"]
@mut("COMUM-01","valor NaN-like 1e999 em resultado")
def _(r,c): conta(r,"K3")["resultado"]["valor"]=Decimal("1E+999")
@mut("COMUM-01","valor com 40 casas")
def _(r,c): ent(r,"V3")["valor"]["valor"]=Decimal("0."+"5"*40)
@mut("COMUM-01","duas acoes (dois JSON)")
def _(r,c): pass
