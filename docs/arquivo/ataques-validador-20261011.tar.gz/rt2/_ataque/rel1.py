import sys; sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
import json
M = []
CASO="REL-BOA-01"
def mut(chk, nome, want="PEGA", caso=CASO):
    def deco(f):
        M.append((chk, nome, want, caso, f)); return f
    return deco
def E(r): return r["entrega"]
def R_(r): return E(r)["resumo"]
def P_(r): return E(r)["proximos_passos"]

# ---- SO-SECOES
@mut("CHK-REL-SO-SECOES","secao extra 'riscos'")
def _(r,c): E(r)["riscos"]=["x"]
@mut("CHK-REL-SO-SECOES","coluna extra 'fonte' numa linha do resumo")
def _(r,c): R_(r)[0]["fonte"]="E1"
@mut("CHK-REL-SO-SECOES","resumo como dicionario")
def _(r,c): E(r)["resumo"]={"1":R_(r)[0]}
@mut("CHK-REL-SO-SECOES","linha do resumo como texto")
def _(r,c): R_(r)[1]="O roteiro foi aprovado. (E2)"
@mut("CHK-REL-SO-SECOES","sem proximos_passos")
def _(r,c): del E(r)["proximos_passos"]
@mut("CHK-REL-SO-SECOES","coluna 'Frase' com maiuscula + 'frase' vazia")
def _(r,c): R_(r)[0]["Frase"]=R_(r)[0].pop("frase")
@mut("CHK-REL-SO-SECOES","campo 'autoavaliacao' extra com numeros e riscos")
def _(r,c): r["autoavaliacao"]="Tudo verificado, sem risco."
# ---- TAMANHO
def fr(n): 
    base="O roteiro e o convite foram aprovados pelo parecer. "
    return (base*10)[:n]
@mut("CHK-REL-TAMANHO-DAS-LINHAS","frase de 280 chars","PASSA")
def _(r,c): R_(r)[1]["frase"]=fr(280)
@mut("CHK-REL-TAMANHO-DAS-LINHAS","frase de 281 chars")
def _(r,c): R_(r)[1]["frase"]=fr(281)
@mut("CHK-REL-TAMANHO-DAS-LINHAS","passo de 241 chars")
def _(r,c): P_(r)[1]["passo"]=fr(241)
@mut("CHK-REL-TAMANHO-DAS-LINHAS","frase so com '.' (sem conteudo)")
def _(r,c): R_(r)[1]["frase"]="."
@mut("CHK-REL-TAMANHO-DAS-LINHAS","5 frases de 280 + refs (passa de 1500?)")
def _(r,c):
    for l in R_(r): l["frase"]=fr(280)
@mut("CHK-REL-TAMANHO-DAS-LINHAS","6 linhas no resumo")
def _(r,c): R_(r).append(dict(R_(r)[1]))
@mut("CHK-REL-TAMANHO-DAS-LINHAS","9 passos")
def _(r,c):
    for i in range(6,10): P_(r).append({"ordem":i,"passo":"Ler o parecer.","depois_de":"nada","refs":"E4"})
@mut("CHK-REL-TAMANHO-DAS-LINHAS","frase de 1 caractere em todo o resumo, refs cobrindo todas as etapas")
def _(r,c):
    for l in R_(r): l["frase"]="x"; l["refs"]="E1, E2, E3, E4"
# ---- ORDEM
@mut("CHK-REL-ORDEM","ordem como texto '1','2'.. ","PASSA?")
def _(r,c):
    for i,l in enumerate(P_(r)): l["ordem"]=str(i+1)
@mut("CHK-REL-ORDEM","ordem 0..4")
def _(r,c):
    for i,l in enumerate(P_(r)): l["ordem"]=i
@mut("CHK-REL-ORDEM","ordem 1.5")
def _(r,c): P_(r)[1]["ordem"]=1.5
@mut("CHK-REL-ORDEM","ordem 2.0 (float inteiro)","PASSA?")
def _(r,c): P_(r)[1]["ordem"]=2.0
@mut("CHK-REL-ORDEM","depois_de '1 e 2' (honesto, outro separador)","PASSA")
def _(r,c): P_(r)[3]["depois_de"]="2 e 3"
@mut("CHK-REL-ORDEM","depois_de 'passo 2' ","PASSA")
def _(r,c): P_(r)[2]["depois_de"]="passo 2"
@mut("CHK-REL-ORDEM","depois_de = ordem do proprio passo")
def _(r,c): P_(r)[2]["depois_de"]="3"
@mut("CHK-REL-ORDEM","depois_de dependencia circular 1 depende de 5")
def _(r,c): P_(r)[0]["depois_de"]="5"
@mut("CHK-REL-ORDEM","ordem como lista [1]")
def _(r,c): P_(r)[0]["ordem"]=[1]
@mut("CHK-REL-ORDEM","ordem null / depois_de null")
def _(r,c): P_(r)[0]["ordem"]=None; P_(r)[1]["depois_de"]=None
@mut("CHK-REL-ORDEM","ordem 1e999 como texto e numero gigante")
def _(r,c): P_(r)[0]["ordem"]="@@RAW:1e999@@"
@mut("CHK-REL-ORDEM","depois_de com 400 digitos")
def _(r,c): P_(r)[1]["depois_de"]="9"*400
# ---- SEM-CODIGO
@mut("CHK-REL-SEM-CODIGO","'E4' (cirilico Е4)")
def _(r,c): R_(r)[2]["frase"]=R_(r)[2]["frase"].replace("O parecer jurídico","O parecer da etapa Е4")
@mut("CHK-REL-SEM-CODIGO","'dec-024' / 'Pf-01' minusculas")
def _(r,c): R_(r)[2]["frase"]=R_(r)[2]["frase"]+" Veja dec-024 e Pf-01."
@mut("CHK-REL-SEM-CODIGO","'etapa E 4' com espaco / 'E-4'")
def _(r,c): R_(r)[2]["frase"]=R_(r)[2]["frase"]+" Veja a etapa E 4 e E-5."
@mut("CHK-REL-SEM-CODIGO","'AGT‑05' hifen nao quebravel")
def _(r,c): R_(r)[2]["frase"]=R_(r)[2]["frase"]+" Feito pelo AGT‑05."
@mut("CHK-REL-SEM-CODIGO","'HELENA' no meio (nome em caps)")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"]+" Revisado por HELENA."
@mut("CHK-REL-SEM-CODIGO","EXE-REL-001 / TSK-9 / JOB-3 (prefixo na lista) e 'EXE-REL-001' (fora da lista)")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"]+" Execução EXE-REL-001."
@mut("CHK-REL-SEM-CODIGO","nome de maquina 'DEPENDENCIA_MUDOU' em minusculas")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"]+" Estado dependencia_mudou."
@mut("CHK-REL-SEM-CODIGO","id de etapa por extenso 'a etapa cinco' e 'SRV' em espaco 'SRV CALCULO'")
def _(r,c): R_(r)[0]["frase"]=R_(r)[0]["frase"]+" Serviço SRV CALCULO na etapa cinco."
