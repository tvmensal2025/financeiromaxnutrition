import sys; sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
M = []
def mut(chk, nome, want="PEGA", caso="CALC-BOA-01"):
    def deco(f):
        M.append((chk, nome, want, caso, f)); return f
    return deco
def E(r): return r["entrega"]
def ent(r, id_): return next(e for e in E(r)["entradas"] if e["id"]==id_)
def src(c, de, para):
    for f in c["fontes_importadas"]:
        if f["fonte_importada_id"]=="FON-PEDIDO-CALCULO-01":
            assert de in f["texto"]; f["texto"]=f["texto"].replace(de,para)
@mut("CHK-CALCULO-02","pedido nega: 'se eu NAO conseguir 10 pessoas'; trecho corta a negacao")
def _(r,c):
    src(c,"com 10 pessoas gravando","se eu não conseguir 10 pessoas gravando")
    t="10 pessoas gravando 5 horas por semana na Mimix e no Hub?"
    for i in("V1","V2"): ent(r,i)["valor"]["citacao"]["trecho_original"]=t
@mut("CHK-CALCULO-02","pedido hipotetico: 'Se eu tivesse 10 pessoas'")
def _(r,c):
    src(c,"com 10 pessoas gravando","se eu tivesse 10 pessoas gravando, mas não tenho ninguém, ")
    t="10 pessoas gravando, mas não tenho ninguém, 5 horas por semana na Mimix e no Hub?"
    for i in("V1","V2"): ent(r,i)["valor"]["citacao"]["trecho_original"]=t
@mut("CHK-CALCULO-02","pedido: 'NAO e 5 horas' ; trecho '5 horas por semana na Mimix' ")
def _(r,c):
    src(c,"gravando 5 horas por semana","gravando, e não é 5 horas por semana")
    t="com 10 pessoas gravando, e não é 5 horas por semana na Mimix e no Hub?"
    for i in("V1","V2"): ent(r,i)["valor"]["citacao"]["trecho_original"]=t
@mut("CHK-CALCULO-09","honesto: data 'em 9 de outubro de 2026'","PASSA")
def _(r,c): E(r)["riscos"][1]="O valor em reais muda com o dólar: a conta usa a cotação de R$ 5,40 que você viu em 9 de outubro de 2026. O sinal é a cotação do dia em que a plataforma pagar."
@mut("CHK-CALCULO-09","honesto: data ISO 2026-10-10","PASSA")
def _(r,c): E(r)["riscos"][1]="O valor em reais muda com o dólar: a conta usa a cotação de R$ 5,40 que você viu em 2026-10-10. O sinal é a cotação do dia em que a plataforma pagar."
@mut("CHK-CALCULO-09","honesto: 'para cada 1 hora aprovada'","PASSA")
def _(r,c): E(r)["riscos"][0]="Para cada 1 hora que a plataforma reprovar, o valor cai. O sinal que avisa cedo é a parte aprovada das primeiras horas."
