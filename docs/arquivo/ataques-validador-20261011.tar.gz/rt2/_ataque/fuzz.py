import sys, json, copy, time, signal, traceback
sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
VARS=[None,0,-1,"",[],{},True,"x",[None],{"a":1},[[]],"1e999","  ","​",3.5,10**40,["a","b"],{"valor":1,"origem":"PREMISSA"},{"trecho_original":"x"}]
def paths(o, p=()):
    yield p
    if isinstance(o, dict):
        for k,v in o.items(): yield from paths(v, p+(k,))
    elif isinstance(o, list):
        for i,v in enumerate(o): yield from paths(v, p+(i,))
def setp(o, p, v):
    for k in p[:-1]: o=o[k]
    o[p[-1]]=v
class TO(Exception): pass
def h(*a): raise TO()
signal.signal(signal.SIGALRM, h)
caso=sys.argv[1]
r0,c=base(caso)
found={}
n=0; t0=time.time()
for p in paths(r0["entrega"]):
    if not p: continue
    for v in VARS:
        r=copy.deepcopy(r0); 
        try: setp(r["entrega"],p,copy.deepcopy(v))
        except Exception: continue
        n+=1
        signal.alarm(10)
        try:
            validar(json.dumps(r,ensure_ascii=False,default=str), c)
        except TO:
            found.setdefault(("TIMEOUT",),[]).append((p,v))
        except Exception as e:
            found.setdefault((type(e).__name__, str(e)[:80], traceback.extract_tb(e.__traceback__)[-1].name),[]).append((p,v))
        finally:
            signal.alarm(0)
print("runs",n,"seg",round(time.time()-t0,1))
for k,v in found.items():
    print(k, len(v), v[:3])
