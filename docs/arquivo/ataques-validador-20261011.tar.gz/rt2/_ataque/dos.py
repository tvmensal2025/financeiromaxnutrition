import sys, json, time, copy, re
sys.path.insert(0,"/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt2/_ataque")
from h import *
which=sys.argv[1]
r,c=base("CALC-BOA-01")
E=r["entrega"]
def raw(r, marker): 
    return re.sub(r'"@@RAW:([^@]*)@@"', r'\1', json.dumps(r, ensure_ascii=False))
if which=="exp+":
    E["entradas"][0]["valor"]["valor"]="@@RAW:1e999999999@@"
elif which=="exp-":
    E["entradas"][0]["valor"]["valor"]="@@RAW:1e-999999999@@"
elif which=="res+":
    E["contas"][0]["resultado"]["valor"]="@@RAW:1e-999999999@@"
elif which=="cen":
    E["cenarios"][0]["resultado"]["valor"]="@@RAW:1e999999999@@"
t=time.time()
out=rodar(raw(r,"x"),c,show=True)
print("tempo", round(time.time()-t,2))
