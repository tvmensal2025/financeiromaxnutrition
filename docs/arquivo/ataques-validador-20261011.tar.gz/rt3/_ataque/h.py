import sys, copy, json
sys.path.insert(0, "/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt3/motor/validador")
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_contexto, carregar_pedido
from validador import validar

SPEC = prova.spec_padrao()
_CASOS = {c.id: c for c in listar_casos(SPEC)}

def base(caso_id):
    c = _CASOS[caso_id]
    return c, copy.deepcopy(c.dados["resposta"])

def rodar(caso_id, mut, ctx_mut=None, verbose=True, rotulo=""):
    c, resp = base(caso_id)
    r = mut(resp) or resp
    ctx = montar_contexto(SPEC, c)
    if ctx_mut:
        ctx = ctx_mut(ctx) or ctx
    txt = r if isinstance(r, str) else json.dumps(r, ensure_ascii=False)
    try:
        rel = validar(txt, ctx)
    except Exception as e:
        print(f"[{rotulo}] EXCECAO {type(e).__name__}: {e}")
        return None
    falhas = [(f.id, f.gravidade, f.motivo, f.item) for f in rel.falhas]
    if verbose:
        print(f"[{rotulo}] recusas={sorted({(f[0],f[2]) for f in falhas if f[1]=='RECUSA'})} marcas={sorted({(f[0],f[2]) for f in falhas if f[1]=='MARCA'})}")
    return rel

def pega(rel, chk=None):
    if rel is None: return None
    return [(f.id, f.gravidade, f.motivo, f.item) for f in rel.falhas if (chk is None or f.id == chk)]
