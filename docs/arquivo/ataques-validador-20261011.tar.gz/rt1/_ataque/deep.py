from h import *
r,x = base("COPY-BOA-01")
j=json.dumps(r,ensure_ascii=False)
for n in (500, 5000, 100000):
    deep = "["*n + "]"*n
    raw = j[:-1] + ', "extra": ' + deep + "}"
    print(n, "copy-extra-deep", run(r,x,raw=raw))
    r2 = json.loads(j); 
    raw2 = j.replace('"onde_usar": "', '"onde_usar_x": '+deep+', "onde_usar": "',1)
    print(n, "deep em campo entrega", run(r,x,raw=raw2))
    raw3 = deep
    print(n, "so deep", run(r,x,raw=raw3))
raw = '{"acao": "ENTREGAR", "acao": "ENTREGAR", ' + j[1:]
print("chave duplicada", run(r,x,raw=raw))
big = j.replace('"parecer": "OK"', '"parecer": "OK", "entrega": {"versao_final": "renda extra garantida"}',1)
print("entrega duplicada (1a com renda, 2a limpa)", run(r,x,raw=big))
