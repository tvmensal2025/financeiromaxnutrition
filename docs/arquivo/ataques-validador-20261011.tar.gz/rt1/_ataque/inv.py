from bat import *
from bt import tm
fil = {"hangul filler 3164":"ㅤ","braille blank":"⠀","hangul 115f":"ᅟ","hangul 1160":"ᅠ","ideographic space 3000":"　","khmer b4":"឴","mongolian vs 180b":"᠋","combining joiner 34f":"͏","thin space":" ","zero width nbsp":"﻿","halfwidth hangul filler ffa0":"ﾠ","variation sel fe0f":"️","U+00AD":"­", "U+2063":"⁣", "ʻ modifier letter":"ʻ", "regional indicator":"\U0001F1E6"}
print("== COPY-03 'garantido' com char separador; COPY-01 'renda'")
for n,c in fil.items():
    r,x = base("COPY-BOA-01"); r["entrega"]["versao_final"] += " Resultado gar"+c+"antido."
    st,out = run(r,x); print(f"  [03 {n}]", sorted({i for i,m,g in out if g=='RECUSA'}))
    r,x = base("COPY-BOA-01"); r["entrega"]["versao_final"] += " Tem ren"+c+"da extra."
    st,out = run(r,x); print(f"  [01 {n}]", sorted({i for i,m,g in out if g=='RECUSA'}))
print("== TREINO-01 'renda' / 09 'remedio'")
for n,c in fil.items():
    r,x = base("TREINO-BOA-01"); r["entrega"]["preparacao"].append("Tem ren"+c+"da.")
    st,out = run(r,x); print(f"  [T01 {n}]", sorted({i for i,m,g in out if g=='RECUSA'}))
