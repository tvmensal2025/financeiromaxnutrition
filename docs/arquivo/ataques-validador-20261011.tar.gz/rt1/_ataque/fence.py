from h import *
r,x = base("COPY-BOA-01")
j=json.dumps(r,ensure_ascii=False)
for nome,raw in [("fence json","```json\n"+j+"\n```"),("fence sem lang","```\n"+j+"\n```"),("BOM", "﻿"+j),("espaços/quebras ao redor","\n\n  "+j+"  \n"),("json indentado", json.dumps(r,ensure_ascii=False,indent=2))]:
    print(nome, run(r,x,raw=raw))
