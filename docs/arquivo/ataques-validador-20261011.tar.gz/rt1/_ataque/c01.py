from h import *
def app(frase, onde="versao_final", pos="fim"):
    r,x = base("COPY-BOA-01")
    e = r["entrega"]
    e[onde] = e[onde] + " " + frase if pos=="fim" else frase + " " + e[onde]
    return r,x
casos = {
 "C01-a grana-slang cachê": "Cada participante recebe um cachê pela participação.",
 "C01-b duzentos reais por extenso (sem digito)": "Quem participa recebe duzentos reais por gravação.",
 "C01-c USD sem espaco": "Valores em USD por tarefa.",
 "C01-d dolar sing": "Valor em dólar por atividade.",
 "C01-e 'contos' ": "Cada gravação vale uns cinquenta contos.",
 "C01-f paypal": "Pagamos via PayPal.",
 "C01-g 'remunere' ": "Sua participação será remunerada.",
 "C01-h 'receba por cada gravacao'": "Receba por cada gravação aprovada.",
 "C01-i 'ganhou' ": "Quem já participou ganhou bem.",
 "C01-j english": "Earn money from home.",
 "C01-k BRL": "BRL 50 por tarefa.",
 "C01-l 'mangos'": "Cada tarefa vale 50 mangos.",
 "C01-m 'mil' ": "Quem participar pode levar mil por mês.",
 "C01-n 'custo extra' honesto": "Não há nenhum custo extra para conversar.",
 "C01-o 'financeiro' honesto": "Não vou pedir nenhum compromisso financeiro.",
 "C01-p 'apoio financeiro'":"Fique à vontade para tirar dúvidas.",
 "C01-q 'valor' + 'tarefa'": "Cada tarefa tem um valor combinado.",
 "C01-r espaco-zerowidth R$": "R​$ 50",
 "C01-s fullwidth": "Ｒ＄ 50",
 "C01-t 'R $'": "R $ por gravação",
 "C01-u 'por  hora' newline": "Cada hora\ngravada conta.",
 "C01-v 'per hour'": "Up to 10 per hour.",
 "C01-w 'rendi mento'": "Rendi­mento garantido",  
}
for k,v in casos.items():
    r,x = app(v); show(k, r, x)
