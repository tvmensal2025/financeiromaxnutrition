from h import *
def B(c="COPY-BOA-01"): return base(c)
def t(nome, f, c="COPY-BOA-01"):
    r,x = B(c)
    try: f(r,x)
    except Exception as e: print("mut erro", nome, repr(e)); return
    e = r["entrega"]; 
    show(nome+f" [final={len(e['versao_final'])} alt={len(e['alternativa_curta'])}]", r, x)
def set_len(r, nf, na):
    e=r["entrega"]
    # final: pad com 'bla ' sem digitos
    base_f = e["versao_final"]
    pad = lambda s,n: (s + " " + ("Responda quando quiser. "*100))[:n].rstrip()
    e["versao_final"] = pad(base_f, nf)
    e["alternativa_curta"] = pad(e["alternativa_curta"], na)
    # sem afirmações que dependam do texto: usar frase que cabe no texto base
for nf,na in [(500,300),(500,301),(500,299),(667,400),(666,400),(668,400),(1000,401),(1200,400),(1200,401),(700,420)]:
    t(f"9 {nf}/{na}", lambda r,x: set_len(r,nf,na))
t("9 alt só espaços", lambda r,x: r["entrega"].__setitem__("alternativa_curta","   "))
t("9 alt '.'", lambda r,x: r["entrega"].__setitem__("alternativa_curta","."))
t("9 alt 'Oi'", lambda r,x: r["entrega"].__setitem__("alternativa_curta","Oi"))
t("9 alt vazia", lambda r,x: r["entrega"].__setitem__("alternativa_curta",""))
t("9 alt igual a final com espaços invisíveis", lambda r,x: r["entrega"].__setitem__("alternativa_curta", r["entrega"]["versao_final"][:290]))
# quebras de linha contam? alt 400 chars of newlines+texto
t("9 alt com muitos \\n (conta caracteres)", lambda r,x: r["entrega"].__setitem__("alternativa_curta", "Oi!\n"+"\n"*2000))
# final com muito espaço para esticar o denominador
t("9 final inflado com espaços internos", lambda r,x: (r["entrega"].__setitem__("versao_final", r["entrega"]["versao_final"].replace(" ", " "*3)), r["entrega"].__setitem__("alternativa_curta", r["entrega"]["alternativa_curta"].replace(" ", " "))))
