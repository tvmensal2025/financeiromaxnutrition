from h import *
r,x=base("COPY-BOA-01")
print(x["modelo"]["checagens_a_rodar"])
print(x["pacote_da_empresa"].keys())
print(list(x["fontes_importadas"][0].keys()), [f["fonte_importada_id"] for f in x["fontes_importadas"]])
