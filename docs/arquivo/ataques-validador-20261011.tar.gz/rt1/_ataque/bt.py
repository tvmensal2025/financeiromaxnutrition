from h import *
import copy
BASE="TREINO-BOA-01"
def tm(nome, f, c=BASE, exp=None):
    r,x = base(c)
    try: f(r,x)
    except Exception as e: print("mut erro", nome, repr(e)); return
    st,out = run(r,x)
    if st=="EXCECAO": print(f"[{nome}] EXCECAO {out}"); return
    rec = sorted({(i) for i,m,g in out if g=="RECUSA"}); mar=sorted({i for i,m,g in out if g!="RECUSA"})
    print(f"[{nome}] RECUSA={rec} MARCA={mar}")
def prep_add(txt): 
    return lambda r,x: r["entrega"]["preparacao"].append(txt)
def priv_add(txt): 
    return lambda r,x: r["entrega"]["privacidade_e_terceiros"].append(txt)
def sinal(i,txt):
    return lambda r,x: r["entrega"]["passo_a_passo"][i].__setitem__("sinal", txt)
def obj(txt):
    return lambda r,x: r["entrega"].__setitem__("objetivo", r["entrega"]["objetivo"]+" "+txt)
def evitar(i,txt):
    return lambda r,x: r["entrega"]["erros_que_reprovam"][i].__setitem__("como_evitar", r["entrega"]["erros_que_reprovam"][i]["como_evitar"]+" "+txt)
