from bt import *
def priv(txt): return lambda r,x: r["entrega"]["privacidade_e_terceiros"].append(txt)
L9 = [
 ("emagrecimento","Isso ajuda no emagrecimento."),
 ("perda de peso","Foco em perda de peso."),
 ("tratamento","Auxilia no tratamento da ansiedade."),
 ("curado","Fique curado."),
 ("medicação","Evite medicação."),
 ("sintomas","Alivia sintomas."),
 ("cur@","Isso é cur@."),
 ("c u r a","Isso é c u r a."),
 ("rem-édio hifen","Tome um rem-édio."),
 ("remédio cirílico","Tome um rеmédio."),
 ("r3médio digito","Tome um r3médio."),
 ("dieta","Faça uma dieta."),
 ("exercício prescrito","Faça o exercício que seu médico mandou."),
 ("diagnosticado","Você será diagnosticado."),
 ("prescrições","Siga as prescrições."),
 ("doenças","Evita doenças."),
]
for n,t in L9: tm("T09 "+n, priv(t))
L10 = [
 ("kcal","Sem contar kcal."),
 ("macros","Controle seus macros."),
 ("plano alimentar","Receba um plano alimentar."),
 ("app de treino","É um app de treino."),
 ("plataforma fitness","Uma plataforma fitness."),
 ("emagrecimento","Foco em emagrecimento."),
 ("c@lorias","c@lorias"),
 ("calo-rias","calo-rias"),
 ("c a l o r i a s","c a l o r i a s"),
 ("cal0rias","cal0rias"),
 ("calorias cirílico","сalorias"),
 ("regime","Faça um regime."),
 ("academia","Como uma academia no bolso."),
 ("Doutor Vital médico real","O Doutor Vital é médico e atende você."),
 ("Alex personal","Alex, nosso personal trainer."),
 ("E-living","Conheça a E-living."),
 ("eliving","Conheça a eliving."),
 ("eLiving sem TM","Conheça a eLiving."),
 ("e Living","Conheça a e Living™."),
 ("eLíving","Conheça a eLíving™."),
]
for n,t in L10: tm("T10 "+n, priv(t), c="TREINO-BOA-04")
