from bt import *
def prep(txt): return lambda r,x: r["entrega"]["preparacao"].append(txt)
for n,t in [("empregos","Há empregos disponíveis."),("contratando","Estamos contratando."),("vagas de trabalho","Vagas de trabalho abertas."),("CLT","Registro em CLT."),("empregado","Você é empregado."),("carteira assinada","Com carteira assinada."),("renda garantida","Renda garantida."),("renda  extra  garantida","renda\nextra\ngarantida"),("e m p r e g o","e m p r e g o"),("em-prego","em-prego"),("empr3go","empr3go")]:
    tm("T02 "+n, prep(t))
