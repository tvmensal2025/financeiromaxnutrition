import copy, json, sys
sys.path.insert(0, "/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt1/motor/validador")
from spec_helena import prova
from spec_helena.caso import montar_contexto, listar_casos, carregar_pedido
from validador import validar

SPEC = prova.spec_padrao()
CASOS = {c.id: c for c in listar_casos(SPEC)}

def base(caso_id):
    c = CASOS[caso_id]
    return copy.deepcopy(c.dados["resposta"]), montar_contexto(SPEC, c)

def run(resp, ctx, raw=None):
    txt = raw if raw is not None else json.dumps(resp, ensure_ascii=False)
    try:
        r = validar(txt, ctx)
    except Exception as e:
        return "EXCECAO", f"{type(e).__name__}: {e}"
    return "OK", [(f.id, f.motivo, f.gravidade) for f in r.falhas]

def show(nome, resp, ctx, esperado=None, raw=None):
    st, out = run(resp, ctx, raw)
    if st == "EXCECAO":
        print(f"[{nome}] EXCECAO {out}")
        return
    rec = [(i, m) for i, m, g in out if g == "RECUSA"]
    mar = [(i, m) for i, m, g in out if g != "RECUSA"]
    print(f"[{nome}] RECUSA={rec} MARCA={mar}")
