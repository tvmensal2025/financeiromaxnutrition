from h import *
import copy, itertools, sys, time
VALS = [None, 0, 1.5, True, [], {}, [None], ["x"], {"a":1}, "", " ", [[[[]]]], {"trecho_original":5}, {"trecho_original":"x","fonte_importada_id":"FON-PACOTE-BIZ-003","leitura_id":3}, float("nan"), 10**40, "\u0000", "\ud800" if False else "‮"]
def paths(o, p=()):
    yield p
    if isinstance(o, dict):
        for k,v in o.items(): yield from paths(v, p+(k,))
    elif isinstance(o, list):
        for i,v in enumerate(o): yield from paths(v, p+(i,))
def setp(o, p, v):
    for k in p[:-1]: o=o[k]
    o[p[-1]]=v
exc = {}
for cid in sys.argv[1:]:
    r0,x = base(cid)
    ps = [p for p in paths(r0) if p]
    n=0
    for p in ps:
        for v in VALS:
            r = copy.deepcopy(r0)
            try: setp(r,p,copy.deepcopy(v))
            except Exception: continue
            t0=time.time()
            try:
                txt = json.dumps(r, ensure_ascii=False, allow_nan=True)
            except Exception as e:
                continue
            try:
                validar(txt, x)
            except Exception as e:
                exc.setdefault((cid,type(e).__name__,str(e)[:100]), []).append((p, repr(v)[:40]))
            dt=time.time()-t0
            if dt>2: print("LENTO", cid, p, repr(v)[:30], round(dt,1))
            n+=1
    print(cid, "mutações:", n)
for k,v in exc.items(): print("EXC", k, len(v), v[:3])
print("fim")
