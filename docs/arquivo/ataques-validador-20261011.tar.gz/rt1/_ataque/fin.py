import json
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_contexto
from validador import validar
S=prova.spec_padrao(); C={c.id:c for c in listar_casos(S)}
def go(cid, f):
    c=C[cid]; r=json.loads(json.dumps(c.dados['resposta'])); x=montar_contexto(S,c); f(r['entrega'])
    rel=validar(json.dumps(r,ensure_ascii=False),x); print([(i.id,i.motivo) for i in rel.recusas],[(i.id,i.motivo) for i in rel.falhas if i.gravidade!='RECUSA'])
go('COPY-BOA-01', lambda e: e.__setitem__('versao_final', e['versao_final']+' Fique curado e emagrece rápido.'))
go('COPY-BOA-01', lambda e: e.__setitem__('versao_final', e['versao_final']+' Corram! Resta só a última vaga, apenas hoje.'))
go('COPY-BOA-01', lambda e: e.__setitem__('versao_final', e['versao_final']+' Me mande o seu cpf e uma foto do seu documento.'))
go('COPY-BOA-01', lambda e: e.__setitem__('versao_final', e['versao_final']+' Resultado garanㅤtido.'))
go('TREINO-BOA-01', lambda e: e['preparacao'].append('Tem renㅤda.'))
go('TREINO-BOA-04', lambda e: e['preparacao'].append('Sem c a l o r i a s.'))
go('TREINO-BOA-04', lambda e: e['preparacao'].append('É um app de treino com plano alimentar.'))
go('COPY-BOA-04', lambda e: e.__setitem__('versao_final', e['versao_final']+' Uma plataforma fitness, sem contar kcal.'))
go('COPY-BOA-01', lambda e: e.__setitem__('versao_final', e['versao_final']+' Resultado gar@ntido.'))
