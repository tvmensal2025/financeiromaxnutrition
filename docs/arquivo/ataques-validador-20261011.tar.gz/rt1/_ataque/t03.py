from bt import *
def passo(i, txt):
    return lambda r,x: r["entrega"]["passo_a_passo"][i].__setitem__("o_que_fazer", txt)
base_txt = None
L = [
 ("2 acoes com 'e'","Apoie o celular na bancada e ajuste a câmera na altura do peito."),
 ("2 acoes com virgulas","Apoie o celular, ajuste a câmera, toque em \"Gravar\"."),
 ("2 acoes ponto e virgula","Apoie o celular; ajuste a câmera."),
 ("depois sozinho","Apoie o celular, depois ajuste a câmera."),
 ("antes de","Antes de gravar, avise quem mora com você."),
 ("primeiro...segundo","Primeiro apoie o celular, segundo ajuste a câmera."),
 ("e, em seguida (virgulas)","Apoie o celular e, em seguida, ajuste a câmera."),
 ("e  depois quebra","Apoie o celular e\ndepois ajuste a câmera."),
 ("'e daí'","Apoie o celular e daí ajuste a câmera."),
 ("'e logo'","Apoie o celular e logo ajuste a câmera."),
 ("'logo em seguida'","Apoie o celular logo em seguida ajuste a câmera."),
 ("'após isso'","Apoie o celular. Após isso ajuste a câmera."),
 ("'na sequência'","Apoie o celular e na sequência ajuste a câmera."),
 ("e  depois con ZW","Apoie o celular e de​pois ajuste a câmera."),
 ("duas exclamações","Apoie o celular!!"),
 ("reticências","Aguarde um instante..."),
 ("reticencias unicode","Aguarde um instante…"),
 ("ex.: abreviação","Apoie o celular em um lugar firme, ex.: a bancada."),
 ("sem ponto final","Apoie o celular na bancada"),
 ("ponto dentro de aspas","Toque em \"Gravar.\""),
 ("pergunta interna","Você já avisou? Toque em \"Gravar\"."),
 ("199/200/201 chars", None),
]
for n,t in L[:-1]:
    tm("T03 "+n, passo(1,t))
for n in (199,200,201):
    pre="Apoie o celular na bancada "
    t=(pre+"firme "*50)[:n-1].rstrip()+"."
    t=t+"x"*(n-len(t)) if len(t)<n else t
    t=t[:-1]+"." if t[-1]!="." else t
    tm(f"T03 len={len(t)}", passo(1,t))
# ids
tm("T03 id P01", lambda r,x: r["entrega"]["passo_a_passo"][0].__setitem__("id","P01"))
tm("T03 id p1", lambda r,x: r["entrega"]["passo_a_passo"][0].__setitem__("id","p1"))
tm("T03 id int", lambda r,x: r["entrega"]["passo_a_passo"][0].__setitem__("id",1))
tm("T03 ids repetidos", lambda r,x: r["entrega"]["passo_a_passo"][3].__setitem__("id","P3"))
tm("T03 ids comecam em P2", lambda r,x: [ r["entrega"]["passo_a_passo"][i].__setitem__("id",f"P{i+2}") for i in range(8)])
tm("T03 ordem trocada P2,P1", lambda r,x: r["entrega"]["passo_a_passo"][:2].reverse() or r["entrega"]["passo_a_passo"].__setitem__(slice(0,2), r["entrega"]["passo_a_passo"][1::-1]) )
tm("T03 13 passos", lambda r,x: r["entrega"]["passo_a_passo"].extend([dict(r["entrega"]["passo_a_passo"][0], id=f"P{i}") for i in range(9,14)]))
tm("T03 2 passos", lambda r,x: r["entrega"].__setitem__("passo_a_passo", r["entrega"]["passo_a_passo"][:2]))
tm("T03 passo_a_passo dict", lambda r,x: r["entrega"].__setitem__("passo_a_passo", {"P1": "x"}))
tm("T03 passo_a_passo string", lambda r,x: r["entrega"].__setitem__("passo_a_passo", "1. Faça tudo e depois envie"))
tm("T03 passo o_que_fazer lista", lambda r,x: r["entrega"]["passo_a_passo"][1].__setitem__("o_que_fazer", ["Apoie o celular.","Ajuste a câmera."]))
