from h import *
import time
def tempo(nome, mut, cid="COPY-BOA-01"):
    r,x = base(cid); mut(r)
    t=time.time(); st,out = run(r,x); dt=time.time()-t
    print(f"{nome}: {dt:.1f}s", st, (sorted({i for i,m,g in out if g=='RECUSA'})[:4] if st=='OK' else out))
N=int(sys.argv[1]) if len(sys.argv)>1 else 20000
tempo(f"letras soltas {N}", lambda r: r["entrega"].__setitem__("versao_final", "a "*N+"bc"))
tempo(f"letras soltas ponto {N}", lambda r: r["entrega"].__setitem__("versao_final", "a."*N+"bc"))
tempo(f"digitos separados {N}", lambda r: r["entrega"].__setitem__("versao_final", "1 "*N+"x"))
tempo(f"arrobas {N}", lambda r: r["entrega"].__setitem__("versao_final", "a@"*N))
tempo(f"hifens {N}", lambda r: r["entrega"].__setitem__("versao_final", "a-"*N))
tempo(f"pontos dominio {N}", lambda r: r["entrega"].__setitem__("versao_final", "ab."*N))
