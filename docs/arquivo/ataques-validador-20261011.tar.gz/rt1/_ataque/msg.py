from h import *
r,x = base("TREINO-BOA-01"); r["entrega"]["passo_a_passo"][4]["apoio"]=None
rel = validar(json.dumps(r,ensure_ascii=False), x)
for f in rel.falhas: print(f.id, f.motivo, f.gravidade, f.item, f.mensagem)
