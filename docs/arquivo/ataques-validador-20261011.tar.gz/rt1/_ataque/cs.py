from h import *
import copy
def B(): return base("COPY-BOA-01")
def t(nome, f):
    r,x = B(); 
    try: f(r,x)
    except Exception as e: print("mut erro", nome, e); return
    show(nome, r, x)
# type confusions
t("S1 versao_final como lista de str (com renda)", lambda r,x: r["entrega"].__setitem__("versao_final", [r["entrega"]["versao_final"], "Ganhe uma renda extra!"]))
t("S2 versao_final como citacao-dict c/ renda", lambda r,x: r["entrega"].__setitem__("versao_final", {"trecho_original": r["entrega"]["versao_final"]+" Ganhe renda extra.", "fonte_importada_id":"FON-PEDIDO-COPY-01"}))
t("S3 versao_final numero", lambda r,x: r["entrega"].__setitem__("versao_final", 123))
t("S4 campo extra na entrega com renda", lambda r,x: r["entrega"].__setitem__("versao_whatsapp", "Ganhe renda extra com garantia, R$ 500"))
t("S5 campo extra na raiz com renda", lambda r,x: r.__setitem__("nota", "Ganhe renda extra com garantia, R$ 500"))
t("S6 campo extra na linha da tabela", lambda r,x: r["entrega"]["afirmacoes"][0].__setitem__("comentario", "Ganhe renda extra"))
t("S7 campo extra dentro do apoio", lambda r,x: r["entrega"]["afirmacoes"][0]["apoio"].__setitem__("obs", "renda extra garantida R$ 500"))
t("S8 afirmacoes vazia", lambda r,x: r["entrega"].__setitem__("afirmacoes", []))
t("S9 afirmacoes ids repetidos", lambda r,x: r["entrega"]["afirmacoes"][1].__setitem__("id","A1"))
t("S10 afirmacoes ordem trocada", lambda r,x: r["entrega"]["afirmacoes"].reverse())
t("S11 id A0", lambda r,x: r["entrega"]["afirmacoes"][0].__setitem__("id","A0"))
t("S12 id 'a1' minúsculo", lambda r,x: r["entrega"]["afirmacoes"][0].__setitem__("id","a1"))
t("S13 id com newline 'A1\\n'", lambda r,x: r["entrega"]["afirmacoes"][0].__setitem__("id","A1\n"))
t("S14 9 afirmacoes", lambda r,x: r["entrega"]["afirmacoes"].extend([{"id":f"A{i}","frase":r["entrega"]["afirmacoes"][0]["frase"],"apoio":r["entrega"]["afirmacoes"][0]["apoio"]} for i in range(6,10)]))
t("S15 o_que_precisa_aprovacao string", lambda r,x: r["entrega"].__setitem__("o_que_precisa_aprovacao", "x"))
t("S16 limites vazio", lambda r,x: r["entrega"].__setitem__("limites", []))
t("S17 duas acoes json (lista)", lambda r,x: None)
# JSON com duas acoes
r,x=B(); raw=json.dumps(r,ensure_ascii=False)+"\n"+json.dumps(r,ensure_ascii=False)
show("S17 dois JSONs concatenados", r, x, raw=raw)
r2=copy.deepcopy(r); r2["entrega"]["versao_final"]+=" Ganhe renda extra."
raw=json.dumps(r,ensure_ascii=False)+"\n"+json.dumps(r2,ensure_ascii=False)
show("S18 dois JSONs, o segundo com renda", r, x, raw=raw)
raw="Aqui está:\n```json\n"+json.dumps(r2,ensure_ascii=False)+"\n```"
show("S19 json em markdown com renda", r, x, raw=raw)
raw=json.dumps(r,ensure_ascii=False)+"\nPS: ganhe renda extra"
show("S20 texto depois do json", r, x, raw=raw)
raw=json.dumps([r],ensure_ascii=False)
show("S21 json em lista", r, x, raw=raw)
t("S22 acao_externa tipo NENHUMA mas fala de enviar", lambda r,x: r.__setitem__("acao_externa", {"tipo":"NENHUMA"}))
t("S23 parecer vazio", lambda r,x: r.__setitem__("parecer", ""))
