import json, sys
sys.path.insert(0, "/tmp/claude-0/-home-user-financeiromaxnutrition/e6bad39a-0168-57f5-beb5-182463b5f582/scratchpad/wt/rt1/motor/validador")
from spec_helena import prova
from spec_helena.caso import listar_casos, montar_contexto
from validador import validar
S = prova.spec_padrao(); C = {c.id: c for c in listar_casos(S)}
def rod(cid, mut):
    c = C[cid]; r = json.loads(json.dumps(c.dados['resposta'])); x = montar_contexto(S, c); mut(r, x)
    rel = validar(json.dumps(r, ensure_ascii=False), x)
    return [(f.id, f.motivo) for f in rel.recusas], [(f.id, f.motivo) for f in rel.falhas if f.gravidade != 'RECUSA']
def fim(sec, txt): return lambda r, x: r['entrega'].__setitem__(sec, r['entrega'][sec] + ' ' + txt)
def lst(sec, txt): return lambda r, x: r['entrega'][sec].append(txt)
CP, TR, EL = 'COPY-BOA-01', 'TREINO-BOA-01', 'COPY-BOA-04'
R = [
 ("E1 treino money", TR, lst('preparacao', 'Você recebe 5 reais por gravação aprovada.')),
 ("E1b treino R $ 5", TR, lst('preparacao', 'Você recebe R $ 5 por gravação.')),
 ("E1c treino r e n d a", TR, lst('preparacao', 'Uma r e n d a nova.')),
 ("E2 negacao regra", TR, lambda r,x: r['entrega']['erros_que_reprovam'][0].__setitem__('o_que_acontece', 'Gravação tremida não é reprovada.')),
 ("E3 copy-02 contratando", CP, fim('versao_final', 'Estamos contratando.')),
 ("E3b copy-02 vagas de trabalho", CP, fim('versao_final', 'Estamos abrindo vagas de trabalho.')),
 ("E3c copy-02 CLT", CP, fim('versao_final', 'Registro em CLT.')),
 ("E3d treino-02 contratando", TR, lst('preparacao', 'Estamos contratando.')),
 ("E4 garanto", CP, fim('versao_final', 'Eu garanto que vai dar certo.')),
 ("E4b sem riscos", CP, fim('versao_final', 'Sem riscos para você.')),
 ("E4c corram", CP, fim('versao_final', 'Corram! Resta só a última vaga, apenas hoje.')),
 ("E5 emagrecimento", CP, fim('versao_final', 'Ajuda no emagrecimento.')),
 ("E5b curado", CP, fim('versao_final', 'Fique curado, perda de peso garantida.')),
 ("E5c treino emagrecimento", TR, lst('preparacao', 'Isso ajuda no emagrecimento.')),
 ("E6 plataforma fitness", EL, fim('versao_final', 'Uma plataforma fitness, sem contar kcal, com plano alimentar.')),
 ("E6b treino-10", 'TREINO-BOA-04', lst('preparacao', 'É um app de treino de academia com plano alimentar.')),
 ("E7 cpf minusc", CP, fim('versao_final', 'Me mande o seu cpf e uma foto do seu documento.')),
 ("E7b cartao", CP, fim('versao_final', 'Informe o número do seu cartão.')),
 ("E8 10k", CP, fim('versao_final', 'Já são 10k pessoas.')),
 ("E8b 10mil", CP, fim('versao_final', 'Já são 10mil pessoas.')),
 ("E8c 10 milhares", CP, fim('versao_final', 'Já são 10 milhares de pessoas.')),
 ("E8d 10,000", CP, fim('versao_final', 'Já são 10,000 pessoas.')),
 ("E8e treino 15k", TR, lst('preparacao', 'Grave 15k vezes.')),
 ("E9 valor reusado", CP, fim('versao_final', 'Em 10 dias você já vê resultado, com 10 horas por semana.')),
 ("E9b treino 5 horas", TR, lst('preparacao', 'Reserve 5 horas e grave por 15 dias seguidos.')),
 ("E10 C-11", CP, fim('versao_final', 'Já temos 11 pessoas confirmadas.')),
 ("E10b extenso", CP, fim('versao_final', 'Mais de quinhentas pessoas já participam.')),
 ("E11 linktr.ee", CP, fim('versao_final', 'Veja em linktr.ee/humano.')),
 ("E11b bit.ly", CP, fim('versao_final', 'Veja em bit.ly/humano.')),
 ("E11c treino t.me", TR, lst('limites', 'Dúvidas: t.me/humano')),
 ("E11d treino linktr", TR, lst('limites', 'Dúvidas: linktr.ee/humano')),
 ("E12 cachê", CP, fim('versao_final', 'Cada participante recebe um cachê pela participação.')),
 ("E12b mil por mês", CP, fim('versao_final', 'Quem participar pode levar mil por mês.')),
 ("E12c contos", CP, fim('versao_final', 'Cada gravação vale uns cinquenta contos.')),
 ("E13 hangul filler garantido", CP, fim('versao_final', 'Resultado garanㅤtido.')),
 ("E13b treino hangul renda", TR, lst('preparacao', 'Tem renㅤda.')),
 ("E13c espaço gar antido", CP, fim('versao_final', 'Resultado gar antido.')),
 ("E13d garantidø", CP, fim('versao_final', 'Resultado garantidø.')),
 ("E14 treino c a l o r i a s", 'TREINO-BOA-04', lst('preparacao', 'Sem c a l o r i a s e sem calo-rias.')),
 ("E14b copy gar@ntido", CP, fim('versao_final', 'Resultado gar@ntido.')),
 ("E15 duas acoes e", TR, lambda r,x: r['entrega']['passo_a_passo'][1].__setitem__('o_que_fazer', 'Apoie o celular na bancada e ajuste a câmera na altura do peito.')),
 ("E15b virgulas", TR, lambda r,x: r['entrega']['passo_a_passo'][1].__setitem__('o_que_fazer', 'Apoie o celular, ajuste a câmera, toque em "Gravar".')),
 ("E16 guillemets", TR, lambda r,x: r['entrega']['passo_a_passo'][7].__setitem__('o_que_fazer', 'Toque no botão «Iniciar agora».')),
 ("E16b o_que_acontece", TR, lambda r,x: r['entrega']['erros_que_reprovam'][0].__setitem__('o_que_acontece', 'Gravação tremida é reprovada. Use o botão "Estabilizar".')),
 ("E16c preparacao", TR, lst('preparacao', 'Abra o app e toque em "Configurações > Permissões".')),
 ("E16d truncado", TR, lambda r,x: r['entrega']['passo_a_passo'][7].__setitem__('o_que_fazer', 'Toque no botão "Enviar".')),
 ("E17 passo sem apoio contradiz", TR, lambda r,x: r['entrega']['passo_a_passo'][1].__setitem__('o_que_fazer', 'Segure o celular na mão durante toda a gravação.') or r['entrega']['passo_a_passo'][1].pop('apoio')),
 ("E17b criancas", TR, lambda r,x: r['entrega']['passo_a_passo'][0].__setitem__('o_que_fazer', 'Peça para as crianças da casa aparecerem na gravação.') or r['entrega']['passo_a_passo'][0].pop('apoio')),
 ("E18 checklist vago", TR, lambda r,x: r['entrega']['checklist_final'].__setitem__(0, 'P1, P2, P3, P4, P5, P6, P7, P8, E1, E2, E3 e E4: você fez tudo certo?')),
 ("E19 sinal ''", TR, lambda r,x: r['entrega']['passo_a_passo'][4].__setitem__('sinal', '')),
 ("E19b como_evitar espacos", TR, lambda r,x: r['entrega']['erros_que_reprovam'][0].__setitem__('como_evitar', '   ')),
 ("E19c privacidade vazias", TR, lambda r,x: r['entrega'].__setitem__('privacidade_e_terceiros', ['', ''])),
 ("E19d copy aprovacao ['']", CP, lambda r,x: r['entrega'].__setitem__('o_que_precisa_aprovacao', [''])),
 ("E19e copy limites ['']", CP, lambda r,x: r['entrega'].__setitem__('limites', [''])),
 ("E20 apoio.obs", TR, lambda r,x: r['entrega']['erros_que_reprovam'][0]['apoio'].__setitem__('obs', 'Você recebe 5 reais por gravação')),
 ("E21 marcador", TR, lst('preparacao', '20 - minutos é o tempo.')),
 ("E22 apoio nao sustenta", CP, lambda r,x: r['entrega']['afirmacoes'][2].__setitem__('apoio', r['entrega']['afirmacoes'][1]['apoio'])),
 ("E22b frase trivial", CP, lambda r,x: r['entrega']['afirmacoes'][2].__setitem__('frase', 'Oi')),
 ("E22c alegacao fora da tabela", CP, fim('versao_final', 'Centenas de pessoas já participam e adoraram.')),
 ("E23 alt '.'", CP, lambda r,x: r['entrega'].__setitem__('alternativa_curta', '.')),
 ("R1 apoio null", TR, lambda r,x: r['entrega']['passo_a_passo'][4].__setitem__('apoio', None)),
 ("R2 extra", CP, fim('versao_final', 'Não tem custo extra para conversar.')),
 ("R2b financeiro", CP, fim('versao_final', 'Não é nada financeiro.')),
 ("R3 em seguida", TR, lambda r,x: r['entrega']['passo_a_passo'][6].__setitem__('o_que_fazer', 'Em seguida, assista à gravação inteira antes de enviar.')),
 ("R3b ex.", TR, lambda r,x: r['entrega']['passo_a_passo'][1].__setitem__('o_que_fazer', 'Apoie o celular deitado, ex.: sobre a bancada.')),
 ("R4 slogan sem ponto", EL, lambda r,x: [r['entrega'].__setitem__(k, r['entrega'][k].replace('Onde sua evolução ganha direção.', 'Onde sua evolução ganha direção')) for k in ('versao_final','alternativa_curta')] and r['entrega']['afirmacoes'][1].__setitem__('frase','Onde sua evolução ganha direção')),
]
import sys
only = sys.argv[1:]
for nome, cid, mut in R:
    if only and not any(nome.startswith(o) for o in only): continue
    try:
        rec, mar = rod(cid, mut)
        print(f"{nome:34s} RECUSA={sorted(set(rec))} MARCA={sorted(set(mar))}")
    except Exception as e:
        print(f"{nome:34s} EXCECAO {type(e).__name__}: {e}")
