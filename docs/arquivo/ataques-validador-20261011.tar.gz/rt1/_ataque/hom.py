from bat import *
tests = {
 "armenian o (օ) em garantido ->'garantidօ'":"garantidօ",
 "small caps ɢᴀʀᴀɴᴛɪᴅᴏ":"ɢᴀʀᴀɴᴛɪᴅᴏ",
 "d com traço đ em 'đinheiro'":"đinheiro",
 "ø em 'garantidø'":"garantidø",
 "ł em 'cłura'":"ł",
 "ı dotless":"garantıdo",
 "cirílico 'рrescrição'":"рrescrição",
 "cirilico 'ѕ' em ganho":"ganhо",
 "grego ο":"garantidο",
 "math bold 𝗴𝗮𝗿𝗮𝗻𝘁𝗶𝗱𝗼":"𝗴𝗮𝗿𝗮𝗻𝘁𝗶𝗱𝗼",
 "circled ⓖⓐⓡⓐⓝⓣⓘⓓⓞ":"ⓖⓐⓡⓐⓝⓣⓘⓓⓞ",
 "g a r a n t i d o c/ NBSP":"g a r a n t i d o",
 "gar antido espaço":"gar antido",
 "garan-\\ntido (hifenização quebra)":"garan-\ntido",
 "g.a.r.a.n.t.i.d.o":"g.a.r.a.n.t.i.d.o",
 "ga_ran_tido":"ga_ran_tido",
 "garantiiido repetido":"garantiiido",
 "garantido com 'ç' trocado: garantidó":"garantidó",
 "GARANTIDO fullwidth":"ＧＡＲＡＮＴＩＤＯ",
 "g‍arantido (ZWJ)":"g‍arantido",
 "'garan' + '​' + 'tido' via U+2062":"garan⁢tido",
 "gar&shy;antido literal entity":"gar&shy;antido",
 "gar<b>antido</b> html":"gar<b>antido</b>",
 "G-A-R-A-N-T-I-D-O":"G-A-R-A-N-T-I-D-O",
 "ga'rantido":"ga'rantido",
 "ga|rantido":"ga|rantido",
 "ga/rantido":"ga/rantido",
 "ga~rantido":"ga~rantido",
 "ga:rantido":"ga:rantido",
 "ga,rantido":"ga,rantido",
}
for k,v in tests.items():
    r,x = base("COPY-BOA-01"); r["entrega"]["versao_final"] += " Resultado "+v+"."
    st,out = run(r,x)
    print(f"[03 {k}] RECUSA=", sorted({i for i,m,g in out if g=='RECUSA'}), "MARCA=", sorted({i for i,m,g in out if g!='RECUSA'}))
