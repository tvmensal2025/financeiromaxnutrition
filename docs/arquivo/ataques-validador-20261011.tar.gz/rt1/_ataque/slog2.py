from bt import *
for nome,s in [("original","Onde sua evolução ganha direção."),("sem ponto","Onde sua evolução ganha direção"),("minusc","onde sua evolução ganha direção."),("slogan + palavra colada","Onde sua evolução ganha direção. ganha dinheiro")]:
    tm("SLOGAN treino "+nome, lambda r,x: r["entrega"].__setitem__("objetivo", r["entrega"]["objetivo"]+" "+s), c="TREINO-BOA-04")
