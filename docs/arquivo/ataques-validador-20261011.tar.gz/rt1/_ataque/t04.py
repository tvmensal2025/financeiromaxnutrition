from bt import *
def passo(i, txt, campo="o_que_fazer"):
    return lambda r,x: r["entrega"]["passo_a_passo"][i].__setitem__(campo, txt)
L = [
 ("aspas retas inventado",'Toque no botão "Iniciar agora".'),
 ("aspas curvas inventado",'Toque no botão “Iniciar agora”.'),
 ("aspas simples inventado","Toque no botão 'Iniciar agora'."),
 ("guillemets inventado","Toque no botão «Iniciar agora»."),
 ("aspas alemãs","Toque no botão „Iniciar agora“."),
 ("backtick","Toque no botão `Iniciar agora`."),
 ("fullwidth quotes","Toque no botão ＂Iniciar agora＂."),
 ("corner brackets","Toque no botão 「Iniciar agora」."),
 ("colchetes","Toque no botão [Iniciar agora]."),
 ("negrito markdown","Toque no botão **Iniciar agora**."),
 ("sem aspas","Toque no botão Iniciar agora."),
 ("nome truncado 'Enviar'",'Toque no botão "Enviar".'),
 ("nome parcial 'Gravar' em  'Minhas gravações'",'Toque na tela "gravações".'),
 ("aspas aninhadas",'Toque em "Enviar para avaliação" e depois em "Confirmar".'),
 ("aspas com quebra de linha no meio",'Toque no botão "Enviar\npara avaliação".'),
 ("aspas vazias",'Toque no botão "".'),
 ("aspas gigantes dentro de palavra","Toque no botão d'Iniciar agora'."),
 ("acento/case diferente",'Toque no botão "ENVIAR PARA AVALIACAO".'),
 ("aspa apostrofo não fechada","Toque no botão 'Iniciar agora."),
 ("aspas com ZW",'Toque no botão "Iniciar​ agora".'),
]
for n,t in L:
    tm("T04 passo "+n, passo(7,t))
tm("T04 inventado em o_que_acontece", lambda r,x: r["entrega"]["erros_que_reprovam"][0].__setitem__("o_que_acontece",'Gravação tremida é reprovada. Use o botão "Estabilizar" para corrigir.'))
tm("T04 inventado em preparacao", lambda r,x: r["entrega"]["preparacao"].append('Abra o app e toque em "Configurações > Permissões".'))
tm("T04 inventado em objetivo", lambda r,x: r["entrega"].__setitem__("objetivo", r["entrega"]["objetivo"]+' Use o modo "Pro".'))
tm("T04 inventado em privacidade", lambda r,x: r["entrega"]["privacidade_e_terceiros"].append('Ative o "Modo privacidade" do app.'))
tm("T04 inventado em limites", lambda r,x: r["entrega"]["limites"].append('Veja a tela "Ajuda".'))
tm("T04 inventado em o_que_precisa_aprovacao", lambda r,x: r["entrega"]["o_que_precisa_aprovacao"].append('Confirme o botão "Enviar agora".'))
tm("T04 inventado em sinal", lambda r,x: r["entrega"]["passo_a_passo"][3].__setitem__("sinal",'Aparece a tela "Gravando agora".'))
tm("T04 inventado em checklist", lambda r,x: r["entrega"]["checklist_final"].__setitem__(0,'P1: você tocou em "Iniciar agora"?'))
tm("T04 inventado em como_evitar", lambda r,x: r["entrega"]["erros_que_reprovam"][0].__setitem__("como_evitar",'Use o botão "Estabilizar".'))
