from bat import *
bat("CHK-COPY-02 (termos do pacote HD)", "COPY-BOA-01", [
 ("plural vagas de trabalho","Estamos abrindo vagas de trabalho."),
 ("empregos","Há empregos disponíveis."),
 ("contratando","Estamos contratando agora."),
 ("contratar","Queremos contratar pessoas."),
 ("empregado","Você será empregado da empresa."),
 ("CLT","Registro em CLT."),
 ("carteira  assinada 2 espacos+quebra","Com carteira\n  assinada."),
 ("EMPREGO maiusc/acento","EMPRÉGO para você."),
 ("em-prego hifen","Um em-prego novo."),
 ("e m p r e g o","Um e m p r e g o novo."),
 ("emprégo c/ cirilico e","Um emprеgo novo."),
 ("vaga de emprego","Vaga de emprego aberta."),
 ("contrataçao sem til","A contratacao é simples."),
 ("renda garantida invert","garantida renda"),
])
