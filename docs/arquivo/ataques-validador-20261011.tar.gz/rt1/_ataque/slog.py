from h import *
def v(txt_final, txt_alt=None, extra_aff=None):
    r,x = base("COPY-BOA-04")
    e=r["entrega"]
    e["versao_final"]=e["versao_final"].replace("Onde sua evolução ganha direção.", txt_final)
    e["alternativa_curta"]=e["alternativa_curta"].replace("Onde sua evolução ganha direção.", txt_alt if txt_alt is not None else txt_final)
    e["afirmacoes"][1]["frase"]=txt_final if txt_final else "Oi"
    return r,x
for nome,s in [("original","Onde sua evolução ganha direção."),("sem ponto final","Onde sua evolução ganha direção"),("com !","Onde sua evolução ganha direção!"),("MAIUSC","ONDE SUA EVOLUÇÃO GANHA DIREÇÃO."),("entre aspas",'"Onde sua evolução ganha direção."'),("aspas sem ponto dentro",'"Onde sua evolução ganha direção".'),("minuscula inicial","onde sua evolução ganha direção."),("espaço duplo","Onde sua  evolução ganha direção."),("com emoji","Onde sua evolução ganha direção. 🚀"),("ponto de interrog.","Onde sua evolução ganha direção?"),("slogan + renda","Onde sua evolução ganha direção. Ganha renda.")]:
    r,x=v(s); show("SLOGAN copy "+nome, r, x)
