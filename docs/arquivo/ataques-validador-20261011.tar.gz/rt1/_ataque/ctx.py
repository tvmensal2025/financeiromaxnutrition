from h import *
import copy
def tc(nome, cid, f):
    r,x = base(cid)
    f(r,x)
    show(nome, r, x)
for cid in ["COPY-BOA-01","TREINO-BOA-01"]:
    tc(cid+" termos_proibidos string", cid, lambda r,x: x["pacote_da_empresa"].__setitem__("termos_proibidos_em_todo_texto","emprego"))
    tc(cid+" termos_proibidos [] ", cid, lambda r,x: x["pacote_da_empresa"].__setitem__("termos_proibidos_em_todo_texto",[]))
    tc(cid+" termos_proibidos com item vazio", cid, lambda r,x: x["pacote_da_empresa"].__setitem__("termos_proibidos_em_todo_texto",["", "emprego"]))
    tc(cid+" termos_proibidos com item so pontuacao '-' ", cid, lambda r,x: x["pacote_da_empresa"].__setitem__("termos_proibidos_em_todo_texto",["-","emprego"]))
    tc(cid+" sem chave termos_proibidos", cid, lambda r,x: x["pacote_da_empresa"].pop("termos_proibidos_em_todo_texto"))
    tc(cid+" pacote None", cid, lambda r,x: x.__setitem__("pacote_da_empresa", None))
    tc(cid+" slogan int", cid, lambda r,x: x["pacote_da_empresa"].__setitem__("slogan", 5))
    tc(cid+" sem fontes", cid, lambda r,x: x.__setitem__("fontes_importadas", []))
    tc(cid+" sem pedido", cid, lambda r,x: x.pop("pedido"))
    tc(cid+" parametros removidos", cid, lambda r,x: x["modelo"].pop("parametros_das_checagens"))
    tc(cid+" empresa BIZ-004 no pedido mas texto HD", cid, lambda r,x: x["pedido"].__setitem__("empresa","BIZ-004"))
