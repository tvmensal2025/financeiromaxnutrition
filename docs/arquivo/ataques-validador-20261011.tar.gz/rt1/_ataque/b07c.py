from bat import *
bat("CHK-COPY-07 codigos do pacote viram numero aceito", "COPY-BOA-01", [
 ("11 (de C-11 no pacote)","Já temos 11 pessoas confirmadas."),
 ("16 (MAT-16)","Já temos 16 pessoas confirmadas."),
 ("24 (DEC-024)","Já temos 24 pessoas confirmadas."),
 ("25","Já temos 25 pessoas confirmadas."),
 ("3 (BIZ-003)","Já temos 3 pessoas confirmadas."),
 ("1 (COPY-01 id fonte)","Já temos 1 pessoa confirmada."),
])
print(base("COPY-BOA-01")[1]["fontes_importadas"][2]["texto"])
