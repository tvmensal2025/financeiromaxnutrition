from bat import *
bat("CHK-COPY-07 b", "COPY-BOA-01", [
 ("10k","Já são 10k pessoas."),
 ("10 k","Já são 10 k pessoas."),
 ("10K","Já são 10K pessoas."),
 ("10 milhares","Já são 10 milhares de pessoas."),
 ("10 trilhões","Já são 10 trilhões de pessoas."),
 ("10 centenas","Já são 10 centenas de pessoas."),
 ("10 dezenas","Já são 10 dezenas de pessoas."),
 ("10 vezes","10 vezes mais rápido."),
 ("10 mil NBSP","10 mil pessoas"),
 ("10-mil hifen","10-mil pessoas"),
 ("10 Mil acentuado Milhão","10 Milhão"),
 ("10.000,00 ","10.000,00 pessoas"),
 ("1.0","1.0 pessoas"),
 ("10 e meio","10 e meio"),
 ("dobro de 10","O dobro de 10 pessoas."),
])
