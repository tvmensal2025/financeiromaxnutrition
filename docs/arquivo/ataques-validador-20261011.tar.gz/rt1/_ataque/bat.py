from h import *
import copy
def anexa(cid, frase, onde="versao_final"):
    r,x = base(cid)
    r["entrega"][onde] = r["entrega"][onde] + " " + frase
    return r,x
def bat(titulo, cid, itens, onde="versao_final"):
    print("==", titulo)
    for nome, frase in itens:
        r,x = anexa(cid, frase, onde)
        st,out = run(r,x)
        if st=="EXCECAO": print(f"  [{nome}] EXCECAO {out}"); continue
        rec = sorted({i for i,m,g in out if g=="RECUSA"})
        mar = sorted({i for i,m,g in out if g!="RECUSA"})
        print(f"  [{nome}] {frase!r:70.70} -> RECUSA={rec} MARCA={mar}")
