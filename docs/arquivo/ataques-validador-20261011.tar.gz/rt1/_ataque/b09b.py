from h import *
r,x = base("COPY-BOA-01")
e=r["entrega"]
comp = " ".join(e["versao_final"].split())
e["alternativa_curta"]=comp
e["versao_final"]=comp.replace(" ", "      ")
print(len(e["versao_final"]), len(e["alternativa_curta"]))
show("COPY-09 alt = final compactada, final inflada com espaços", r, x)
r,x = base("COPY-BOA-01")
e=r["entrega"]
comp = e["versao_final"]
e["alternativa_curta"]=comp[:400]
e["versao_final"]=comp+"\n\n"+(" \n"*350)   # final inflada com linhas em branco
show("COPY-09 alt = 400 primeiros chars da final; final com linhas em branco", r, x)
print(len(e["versao_final"]), len(e["alternativa_curta"]))
