from h import *
for cid in CASOS:
    if "COPY" in cid or "TREIN" in cid or "ROT" in cid:
        c=CASOS[cid]
        r,x = base(cid)
        show(cid, r, x)
