from bt import *
def prep(i, txt): return lambda r,x: r["entrega"]["preparacao"].__setitem__(i, txt)
def evitar0(txt): return lambda r,x: r["entrega"]["erros_que_reprovam"][0].__setitem__("como_evitar", txt)
L = [
 ("5 horas","Reserve 5 horas para gravar."),
 ("15 dias","Grave por 15 dias seguidos."),
 ("5 gravações por dia","Faça 5 gravações por dia."),
 ("às 15h","Grave às 15h."),
 ("15 milhões","Grave 15 milhões de vezes."),
 ("15mil","Grave 15mil vezes."),
 ("15k","Grave 15k vezes."),
 ("5,000","Grave 5,000 vezes."),
 ("5.5","Grave 5.5 vezes."),
 ("05","Grave 05 vezes."),
 ("20 - minutos (marcador)","20 - minutos é o tempo."),
 ("99. dica (marcador)","99. Evite sombras."),
 ("1) item (marcador)","1) Evite sombras."),
 ("10 minutos","Grave 10 minutos."),
 ("quinze minutos extenso","Grave quinze minutos."),
 ("meia hora","Grave meia hora."),
 ("15 %","Grave 15%."),
 ("5/15","Nota 5/15."),
 ("data 14/10/2026","Envie até 14/10/2026."),
 ("data 1/5/2026","Envie até 1/5/2026."),
 ("hora 15:00","Envie às 15:00."),
 ("hora 15h30","Envie às 15h30."),
 ("1 só","Faça uma 1 gravação."),
 ("zero","Faça 0 erros."),
 ("árabe 5","Grave ٥ vezes."),
 ("superscript 15 ¹⁵","Grave ¹⁵ vezes."),
 ("fullwidth １５","Grave １５ vezes."),
 ("número gigante 31 digitos","Grave 1000000000000000000000000000000 vezes."),
]
for n,t in L:
    tm("T07 "+n, prep(0,t))
